# Tamagotchi e-ink

## Atualizar uma instalação existente (ou instalar pela primeira vez)
Copie o novo `tamagotchi.zip` para o Pi e, na pasta onde você descompactou da primeira vez
(a que contém a pasta `tamagotchi`):

    unzip -o tamagotchi.zip
    cd tamagotchi
    ./install.sh

O `install.sh` pode rodar a cada atualização: instala o que faltar, aplica a blindagem contra
travamentos (`harden.sh`) e reinicia o serviço. Seus ajustes, imagens, chaves de API e cache
ficam em `data/`, que o zip não sobrescreve. Configurações antigas continuam valendo.

Depois abra http://<hostname>.local:8080

## O que a blindagem faz (harden.sh)
1. **Watchdog de hardware**: se o Pi congelar de vez, ele reinicia sozinho em ~15 s.
2. **Wi-Fi sem economia de energia** (causa comum de queda de rede no Pi Zero W).
3. **Registro persistente**: o journal sobrevive ao reinício (`journalctl -b -1` mostra o boot anterior).
4. **Monitor de saúde** (1x por minuto) em `/var/log/tamagotchi-health.log`: carga, memória livre,
   swap, temperatura, `throttled` (queda de tensão), sinal do Wi-Fi e se o roteador responde.
   Se a rede cair: 3 min reinicia o Wi-Fi, 6 min reinicia o serviço de rede, 12 min reinicia o Pi
   (no máximo 1 vez por hora).
5. O app tem um **vigia interno**: se a tela travar, a memória passar de 220 MB ou o laço parar,
   ele se reinicia sozinho. E a espera pelo pino BUSY da tela agora tem limite de 30 s.

## Se o Pi travar de novo: o que olhar depois de reiniciá-lo
    tail -40 /var/log/tamagotchi-health.log      # as últimas linhas antes de parar
    vcgencmd get_throttled                        # 0x0 = ok; bit 0 / 0x50005 = queda de tensão (fonte/cabo)
    sudo journalctl -b -1 -e --no-pager | tail -60  # o que o sistema registrou antes de morrer
    dmesg | grep -i -E 'under-voltage|brcmf|oom|mmc|ext4'
    free -h; uptime

Leitura rápida do `throttled`: 0x1 queda de tensão agora; 0x4 limitado agora; 0x10000 houve queda
de tensão desde o boot; 0x40000 houve limitação desde o boot. Qualquer um desses = fonte ou cabo fraco.

## Estrutura (onde mexer quando surgir uma ideia nova)
- `config.py`     valores padrão e validação de tudo que a interface envia
- `renderer.py`   desenha a tela (hora, data, imagem, textos girados, clima, balão do Jorginho)
- `icons.py`      ícones de sol, nuvem, chuva etc. e a classificação das condições
- `phrases.py`    comentários e piadas do Jorginho (basta acrescentar itens nas listas)
- `mascot.py`     quando e o que o Jorginho fala (inclui os comentários sobre o clima)
- `weather.py`    AccuWeather e Open-Meteo, cache e teto de chamadas
- `display.py`    painel e-ink e o relógio de cada minuto (com proteção contra tela travada)
- `app.py`        servidor (waitress), API e vigia interno
- `static/`       a interface (index.html, style.css, app.js)
- `system/`, `harden.sh`  blindagem do sistema operacional

## Variáveis úteis (`sudo systemctl edit tamagotchi`, seção [Service], linhas Environment=...)
- `ACCUWEATHER_API_KEY`, `ACCUWEATHER_DAILY_CAP`  chave e teto diário de chamadas (padrão 100)
- `EPD_LIB`               caminho da biblioteca da Waveshare
- `FULL_REFRESH_EVERY`    atualizações parciais entre duas completas (padrão 20)
- `EPD_BUSY_TIMEOUT`      segundos de espera pela tela antes de dar erro (padrão 30)
- `MAX_RSS_MB`            memória máxima do app antes de se reiniciar (padrão 220)
