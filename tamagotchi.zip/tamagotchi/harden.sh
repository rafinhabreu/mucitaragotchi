#!/usr/bin/env bash
# Deixa o Pi mais resistente a travamentos e faz ele se recuperar sozinho.
# Pode rodar quantas vezes quiser (é idempotente). Chamado pelo install.sh.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "1/5 Watchdog de hardware: o Pi se reinicia sozinho se congelar"
sudo mkdir -p /etc/systemd/system.conf.d
sudo tee /etc/systemd/system.conf.d/10-tamagotchi-watchdog.conf >/dev/null <<'CONF'
[Manager]
RuntimeWatchdogSec=14
RebootWatchdogSec=2min
CONF
[ -e /dev/watchdog ] || sudo modprobe bcm2835_wdt 2>/dev/null || true
[ -e /dev/watchdog ] || echo "   aviso: /dev/watchdog não existe; o watchdog de hardware não vai funcionar neste Pi"

echo "2/5 Wi-Fi sem economia de energia"
if [ -d /etc/NetworkManager/conf.d ]; then
  sudo tee /etc/NetworkManager/conf.d/99-tamagotchi-wifi.conf >/dev/null <<'CONF'
[connection]
wifi.powersave = 2
CONF
fi
sudo install -m 0644 "$DIR/system/tamagotchi-wifi.service" /etc/systemd/system/

echo "3/5 Registro persistente do sistema (sobrevive ao reinício)"
sudo mkdir -p /var/log/journal /etc/systemd/journald.conf.d
sudo tee /etc/systemd/journald.conf.d/10-tamagotchi.conf >/dev/null <<'CONF'
[Journal]
Storage=persistent
SystemMaxUse=40M
RuntimeMaxUse=20M
CONF
sudo systemctl restart systemd-journald

echo "4/5 Monitor de saúde e vigia de rede"
sudo install -m 0755 "$DIR/system/tamagotchi-health.sh" /usr/local/bin/tamagotchi-health
sudo install -m 0644 "$DIR/system/tamagotchi-health.service" /etc/systemd/system/
sudo install -m 0644 "$DIR/system/tamagotchi-health.timer" /etc/systemd/system/

echo "5/5 Ativando"
sudo systemctl daemon-reload
sudo systemctl daemon-reexec   # aplica o watchdog sem precisar reiniciar
sudo systemctl enable --now tamagotchi-wifi.service tamagotchi-health.timer
sudo iw dev wlan0 set power_save off 2>/dev/null || true
echo "Pronto. Log de saúde: tail -f /var/log/tamagotchi-health.log"
