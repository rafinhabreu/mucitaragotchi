"""Configuração do Tamagotchi: valores padrão, validação e gravação em disco."""
import json
import os
import re
import threading
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
IMAGES = DATA / "images"
CONFIG_FILE = DATA / "config.json"

# Resolução da Waveshare 2.13" V4 na orientação paisagem
W, H = 250, 122

FONTS = ("sans", "sans-bold", "mono", "serif")
TIME_FORMATS = ("24h", "12h")
DATE_FORMATS = ("dmy", "dm", "long", "full")
FITS = ("cover", "contain", "stretch")
MODES = ("dither", "threshold")
PROVIDERS = ("accuweather", "openmeteo")
MASCOT_KINDS = ("comment", "joke", "weather")
ALIGNS = ("left", "center", "right")
MAX_TEXTS = 8

DEFAULTS = {
    "rotation": 0,
    "invert": False,
    "time": {
        "enabled": True, "x": 40, "y": 12, "size": 52, "font": "sans-bold",
        "format": "24h", "backdrop": False, "offset_min": 0,
    },
    "date": {
        "enabled": True, "x": 50, "y": 88, "size": 16, "font": "sans",
        "format": "long", "backdrop": False,
    },
    "image": {
        "enabled": False, "file": "", "x": 0, "y": 0, "w": W, "h": H,
        "fit": "cover", "mode": "dither", "threshold": 128,
    },
    "texts": [],
    "weatherbox": {
        "enabled": False, "x": 132, "y": 4, "size": 40, "w": 112, "font": "sans-bold",
        "show_range": True, "show_text": False,
    },
    "weather": {
        "provider": "accuweather", "location_key": "", "location_name": "",
        "location_provider": "",
    },
    "mascot": {
        "enabled": False, "name": "Jorginho",
        "x": 4, "y": 50, "w": 242, "size": 12, "font": "sans",
        "max_lines": 4, "tail": True,
        "interval_min": 15,
        "kinds": {"comment": True, "joke": True, "weather": True},
        "quiet": {"enabled": True, "start": 23, "end": 7},
        "custom": [],
    },
}

TEXT_DEFAULT = {
    "enabled": True, "text": "Olá!", "x": 10, "y": 10, "size": 20, "font": "sans-bold",
    "angle": 0, "align": "left", "backdrop": False, "border": False,
}

_lock = threading.Lock()


def _int(value, lo, hi, default):
    try:
        value = int(round(float(value)))
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, value))


def _bool(value, default):
    return value if isinstance(value, bool) else default


def _angle(value):
    try:
        return int(round(float(value))) % 360
    except (TypeError, ValueError):
        return 0


def _text(value, limit):
    s = "".join(ch for ch in str(value or "") if ch.isprintable())
    return s.strip()[:limit]


def _token(value, limit=40):
    return re.sub(r"[^0-9A-Za-z.,_\-]", "", str(value or ""))[:limit]


def _choice(value, options, default):
    return value if value in options else default


def sanitize(raw):
    """Recebe qualquer coisa e devolve uma configuração completa e válida."""
    raw = raw if isinstance(raw, dict) else {}
    d = DEFAULTS
    out = {
        "rotation": 180 if raw.get("rotation") == 180 else 0,
        "invert": _bool(raw.get("invert"), d["invert"]),
    }

    for key in ("time", "date"):
        r = raw.get(key) if isinstance(raw.get(key), dict) else {}
        dd = d[key]
        el = {
            "enabled": _bool(r.get("enabled"), dd["enabled"]),
            "x": _int(r.get("x"), -W, W, dd["x"]),
            "y": _int(r.get("y"), -H, H, dd["y"]),
            "size": _int(r.get("size"), 8, 100, dd["size"]),
            "font": _choice(r.get("font"), FONTS, dd["font"]),
            "format": _choice(
                r.get("format"),
                TIME_FORMATS if key == "time" else DATE_FORMATS,
                dd["format"],
            ),
            "backdrop": _bool(r.get("backdrop"), dd["backdrop"]),
        }
        if key == "time":
            el["offset_min"] = _int(r.get("offset_min"), -1440, 1440, 0)
        out[key] = el

    r = raw.get("image") if isinstance(raw.get("image"), dict) else {}
    di = d["image"]
    out["image"] = {
        "enabled": _bool(r.get("enabled"), di["enabled"]),
        "file": os.path.basename(str(r.get("file") or "")),
        "x": _int(r.get("x"), -W, W, di["x"]),
        "y": _int(r.get("y"), -H, H, di["y"]),
        "w": _int(r.get("w"), 1, 500, di["w"]),
        "h": _int(r.get("h"), 1, 300, di["h"]),
        "fit": _choice(r.get("fit"), FITS, di["fit"]),
        "mode": _choice(r.get("mode"), MODES, di["mode"]),
        "threshold": _int(r.get("threshold"), 1, 254, di["threshold"]),
    }

    texts = []
    for r in (raw.get("texts") if isinstance(raw.get("texts"), list) else [])[:MAX_TEXTS]:
        r = r if isinstance(r, dict) else {}
        dt_ = TEXT_DEFAULT
        raw_text = str(r.get("text") if r.get("text") is not None else dt_["text"])
        raw_text = "\n".join("".join(ch for ch in ln if ch.isprintable()) for ln in raw_text.replace("\r", "").split("\n")[:6])
        texts.append({
            "enabled": _bool(r.get("enabled"), True),
            "text": raw_text[:200],
            "x": _int(r.get("x"), -W, W, dt_["x"]),
            "y": _int(r.get("y"), -H, H, dt_["y"]),
            "size": _int(r.get("size"), 6, 80, dt_["size"]),
            "font": _choice(r.get("font"), FONTS, dt_["font"]),
            "angle": _angle(r.get("angle")),
            "align": _choice(r.get("align"), ALIGNS, "left"),
            "backdrop": _bool(r.get("backdrop"), False),
            "border": _bool(r.get("border"), False),
        })
    out["texts"] = texts

    r = raw.get("weatherbox") if isinstance(raw.get("weatherbox"), dict) else {}
    db = d["weatherbox"]
    out["weatherbox"] = {
        "enabled": _bool(r.get("enabled"), db["enabled"]),
        "x": _int(r.get("x"), -W, W, db["x"]),
        "y": _int(r.get("y"), -H, H, db["y"]),
        "size": _int(r.get("size"), 20, 80, db["size"]),
        "w": _int(r.get("w"), 50, W, db["w"]),
        "font": _choice(r.get("font"), FONTS, db["font"]),
        "show_range": _bool(r.get("show_range"), db["show_range"]),
        "show_text": _bool(r.get("show_text"), db["show_text"]),
    }

    r = raw.get("weather") if isinstance(raw.get("weather"), dict) else {}
    dw = d["weather"]
    out["weather"] = {
        "provider": _choice(r.get("provider"), PROVIDERS, dw["provider"]),
        "location_key": _token(r.get("location_key")),
        "location_name": _text(r.get("location_name"), 80),
        "location_provider": _choice(r.get("location_provider"), PROVIDERS + ("",), ""),
    }

    r = raw.get("mascot") if isinstance(raw.get("mascot"), dict) else {}
    dm = d["mascot"]
    kinds = r.get("kinds") if isinstance(r.get("kinds"), dict) else {}
    quiet = r.get("quiet") if isinstance(r.get("quiet"), dict) else {}
    custom = r.get("custom") if isinstance(r.get("custom"), list) else []
    out["mascot"] = {
        "enabled": _bool(r.get("enabled"), dm["enabled"]),
        "name": _text(r.get("name"), 20) or dm["name"],
        "x": _int(r.get("x"), -W, W, dm["x"]),
        "y": _int(r.get("y"), -H, H, dm["y"]),
        "w": _int(r.get("w"), 60, W, dm["w"]),
        "size": _int(r.get("size"), 8, 24, dm["size"]),
        "font": _choice(r.get("font"), FONTS, dm["font"]),
        "max_lines": _int(r.get("max_lines"), 1, 8, dm["max_lines"]),
        "tail": _bool(r.get("tail"), dm["tail"]),
        "interval_min": _int(r.get("interval_min"), 1, 720, dm["interval_min"]),
        "kinds": {k: _bool(kinds.get(k), True) for k in MASCOT_KINDS},
        "quiet": {
            "enabled": _bool(quiet.get("enabled"), dm["quiet"]["enabled"]),
            "start": _int(quiet.get("start"), 0, 23, dm["quiet"]["start"]),
            "end": _int(quiet.get("end"), 0, 23, dm["quiet"]["end"]),
        },
        "custom": [t for t in (_text(x, 140) for x in custom[:40]) if t],
    }
    return out


def load():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return sanitize(json.load(f))
    except (OSError, ValueError):
        return sanitize({})


def save(cfg):
    DATA.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG_FILE.with_suffix(".tmp")
    with _lock:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
        os.replace(tmp, CONFIG_FILE)  # gravação atômica


IMAGES.mkdir(parents=True, exist_ok=True)
