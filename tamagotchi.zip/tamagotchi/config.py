"""Configuração do Tamagotchi: valores padrão, validação e gravação em disco."""
import json
import os
import threading
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
IMAGES = DATA / "images"
CONFIG_FILE = DATA / "config.json"

# Resolução da Waveshare 2.13" V4 na orientação paisagem
W, H = 250, 122

FONTS = ("sans", "sans-bold", "mono", "serif")
TIME_FORMATS = ("24h", "12h")
DATE_FORMATS = ("dmy", "dm", "long", "full")
FITS = ("cover", "contain", "stretch")
MODES = ("dither", "threshold")

DEFAULTS = {
    "rotation": 0,
    "invert": False,
    "time": {
        "enabled": True, "x": 40, "y": 12, "size": 52, "font": "sans-bold",
        "format": "24h", "backdrop": False, "offset_min": 0,
    },
    "date": {
        "enabled": True, "x": 50, "y": 88, "size": 16, "font": "sans",
        "format": "long", "backdrop": False,
    },
    "image": {
        "enabled": False, "file": "", "x": 0, "y": 0, "w": W, "h": H,
        "fit": "cover", "mode": "dither", "threshold": 128,
    },
}

_lock = threading.Lock()


def _int(value, lo, hi, default):
    try:
        value = int(round(float(value)))
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, value))


def _bool(value, default):
    return value if isinstance(value, bool) else default


def _choice(value, options, default):
    return value if value in options else default


def sanitize(raw):
    """Recebe qualquer coisa e devolve uma configuração completa e válida."""
    raw = raw if isinstance(raw, dict) else {}
    d = DEFAULTS
    out = {
        "rotation": 180 if raw.get("rotation") == 180 else 0,
        "invert": _bool(raw.get("invert"), d["invert"]),
    }

    for key in ("time", "date"):
        r = raw.get(key) if isinstance(raw.get(key), dict) else {}
        dd = d[key]
        el = {
            "enabled": _bool(r.get("enabled"), dd["enabled"]),
            "x": _int(r.get("x"), -W, W, dd["x"]),
            "y": _int(r.get("y"), -H, H, dd["y"]),
            "size": _int(r.get("size"), 8, 100, dd["size"]),
            "font": _choice(r.get("font"), FONTS, dd["font"]),
            "format": _choice(
                r.get("format"),
                TIME_FORMATS if key == "time" else DATE_FORMATS,
                dd["format"],
            ),
            "backdrop": _bool(r.get("backdrop"), dd["backdrop"]),
        }
        if key == "time":
            el["offset_min"] = _int(r.get("offset_min"), -1440, 1440, 0)
        out[key] = el

    r = raw.get("image") if isinstance(raw.get("image"), dict) else {}
    di = d["image"]
    out["image"] = {
        "enabled": _bool(r.get("enabled"), di["enabled"]),
        "file": os.path.basename(str(r.get("file") or "")),
        "x": _int(r.get("x"), -W, W, di["x"]),
        "y": _int(r.get("y"), -H, H, di["y"]),
        "w": _int(r.get("w"), 1, 500, di["w"]),
        "h": _int(r.get("h"), 1, 300, di["h"]),
        "fit": _choice(r.get("fit"), FITS, di["fit"]),
        "mode": _choice(r.get("mode"), MODES, di["mode"]),
        "threshold": _int(r.get("threshold"), 1, 254, di["threshold"]),
    }
    return out


def load():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return sanitize(json.load(f))
    except (OSError, ValueError):
        return sanitize({})


def save(cfg):
    DATA.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG_FILE.with_suffix(".tmp")
    with _lock:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
        os.replace(tmp, CONFIG_FILE)  # gravação atômica


IMAGES.mkdir(parents=True, exist_ok=True)
