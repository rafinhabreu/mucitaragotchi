"""Desenha a tela (250x122, 1 bit) a partir da configuração.

A mesma imagem alimenta a prévia no navegador e o painel e-ink,
então o que você vê no simulador é exatamente o que vai para a tela.
"""
import base64
import datetime as dt
import io
import math
import os
from functools import lru_cache

from PIL import Image, ImageDraw, ImageFont, ImageOps

import config
import icons
import mascot
import weather

W, H = config.W, config.H
_RS = getattr(Image, "Resampling", Image)
RESAMPLE, BICUBIC, BOX = _RS.LANCZOS, _RS.BICUBIC, _RS.BOX

_DEJAVU = "/usr/share/fonts/truetype/dejavu/"
FONT_FILES = {
    "sans": "DejaVuSans.ttf",
    "sans-bold": "DejaVuSans-Bold.ttf",
    "mono": "DejaVuSansMono-Bold.ttf",
    "serif": "DejaVuSerif.ttf",
}

WEEKDAYS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
MONTHS = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho",
          "agosto", "setembro", "outubro", "novembro", "dezembro"]


@lru_cache(maxsize=32)
def get_font(name, size):
    path = _DEJAVU + FONT_FILES.get(name, FONT_FILES["sans"])
    try:
        return ImageFont.truetype(path, size)
    except OSError:
        try:
            return ImageFont.load_default(size)  # Pillow >= 10.1
        except TypeError:
            return ImageFont.load_default()


def format_time(now, fmt):
    if fmt == "12h":
        return f"{now.hour % 12 or 12}:{now.minute:02d} {'AM' if now.hour < 12 else 'PM'}"
    return f"{now.hour:02d}:{now.minute:02d}"


def format_date(now, fmt):
    wd, mo = WEEKDAYS[now.weekday()], MONTHS[now.month - 1]
    if fmt == "dm":
        return f"{now.day:02d}/{now.month:02d}"
    if fmt == "long":
        return f"{wd[:3]}, {now.day} {mo[:3]} {now.year}"
    if fmt == "full":
        return f"{wd}, {now.day} de {mo}"
    return f"{now.day:02d}/{now.month:02d}/{now.year}"


@lru_cache(maxsize=6)
def _picture(path, mtime, w, h, fit, mode, threshold, bg_white):
    """Carrega, redimensiona e converte a imagem para 1 bit (com cache)."""
    img = ImageOps.exif_transpose(Image.open(path))
    if img.mode in ("RGBA", "LA", "P"):
        rgba = img.convert("RGBA")
        base = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        img = Image.alpha_composite(base, rgba)
    img = ImageOps.autocontrast(img.convert("L"))

    if fit == "cover":
        img = ImageOps.fit(img, (w, h), RESAMPLE)
    elif fit == "contain":
        img = ImageOps.contain(img, (w, h), RESAMPLE)
        base = Image.new("L", (w, h), 255 if bg_white else 0)
        base.paste(img, ((w - img.width) // 2, (h - img.height) // 2))
        img = base
    else:
        img = img.resize((w, h), RESAMPLE)

    if mode == "threshold":
        img = img.point(lambda p: 255 if p >= threshold else 0)
    return img.convert("1")  # pontilhado Floyd–Steinberg quando não é limiar


def load_picture(im, bg_white):
    path = config.IMAGES / os.path.basename(im["file"])
    try:
        return _picture(str(path), path.stat().st_mtime_ns, im["w"], im["h"],
                        im["fit"], im["mode"], im["threshold"], bg_white)
    except Exception:
        return None


def _draw_text(draw, el, text, fg, bg):
    font = get_font(el["font"], el["size"])
    try:
        # Altura estável: do topo de "Á" até o fundo de "g", para a caixa não
        # "pular" quando o texto muda.
        _, top, _, bottom = font.getbbox("Ág0", anchor="la")
        width = int(math.ceil(font.getlength(text)))
    except Exception:
        top, bottom, width = 0, el["size"], len(text) * el["size"] // 2
    height = bottom - top
    x, y = el["x"], el["y"]
    if el["backdrop"]:
        draw.rectangle([x - 3, y - 2, x + width + 2, y + height + 1], fill=bg)
    draw.text((x, y - top), text, font=font, fill=fg, anchor="la")
    return {"x": x, "y": y, "w": width, "h": height}


# --- caixas de texto livres (com rotação de 0 a 359 graus) --------------------------
SUPERSAMPLE = 3  # texto girado é desenhado em 3x e reduzido, para ficar nítido em 1 bit


@lru_cache(maxsize=32)
def _text_masks(text, font_name, size, angle, align, backdrop, border):
    """Máscaras 1-bit (fundo, borda, texto) já giradas. Em cache: arrastar não recalcula."""
    ss = SUPERSAMPLE if angle else 1
    font = get_font(font_name, size * ss)
    spacing = max(1, size // 6) * ss
    probe = ImageDraw.Draw(Image.new("L", (1, 1)))
    l, t, r, b = probe.multiline_textbbox((0, 0), text, font=font, align=align, spacing=spacing)
    l, t, r, b = math.floor(l), math.floor(t), math.ceil(r), math.ceil(b)  # algumas versões do Pillow devolvem decimais
    pad = (3 if (backdrop or border) else 1) * ss
    w, h = r - l + 2 * pad, b - t + 2 * pad

    txt = Image.new("L", (w, h), 0)
    ImageDraw.Draw(txt).multiline_text((pad - l, pad - t), text, font=font, fill=255,
                                       align=align, spacing=spacing)
    fill = Image.new("L", (w, h), 0)
    if backdrop:
        ImageDraw.Draw(fill).rectangle([0, 0, w - 1, h - 1], fill=255)
    edge = Image.new("L", (w, h), 0)
    if border:
        ImageDraw.Draw(edge).rectangle([0, 0, w - 1, h - 1], outline=255, width=ss)

    layers = [fill, edge, txt]
    if angle:
        layers = [im.rotate(-angle, resample=BICUBIC, expand=True) for im in layers]  # horário
        nw, nh = layers[0].size
        layers = [im.resize((max(1, round(nw / ss)), max(1, round(nh / ss))), BOX) for im in layers]
    return tuple(im.point(lambda p: 255 if p >= 110 else 0).convert("1") for im in layers)


def _draw_textbox(canvas, el, fg, bg):
    """(x, y) é o canto superior esquerdo da caixa já girada."""
    x, y = el["x"], el["y"]
    if not el["text"].strip():
        return {"x": x, "y": y, "w": 24, "h": 12}  # só para dar o que arrastar
    fill, edge, txt = _text_masks(el["text"], el["font"], el["size"], el["angle"],
                                  el["align"], el["backdrop"], el["border"])
    fgv, bgv = (255 if fg else 0), (255 if bg else 0)
    if el["backdrop"]:
        canvas.paste(bgv, (x, y), fill)
    if el["border"]:
        canvas.paste(fgv, (x, y), edge)
    canvas.paste(fgv, (x, y), txt)
    return {"x": x, "y": y, "w": txt.width, "h": txt.height}


# --- área do clima (ícone + temperatura) ---------------------------------------------
def _ellipsize(font, text, max_w):
    if font.getlength(text) <= max_w:
        return text
    while text and font.getlength(text + "…") > max_w:
        text = text[:-1]
    return text.rstrip() + "…"


def _draw_weatherbox(draw, el, data, fg, bg):
    x, y, size, gap = el["x"], el["y"], el["size"], 6
    cur = (data or {}).get("current") or {}
    today = (data or {}).get("today") or {}
    temp = cur.get("temp") if cur.get("temp") is not None else None
    cond = cur.get("text") or today.get("text") or ""
    kind = icons.classify(cond, cur.get("icon_id") or today.get("icon_id")) if data else "cloud"
    night = bool(data) and cur.get("is_day") is False

    big = get_font(el["font"], max(10, round(size * 0.62)))
    small = get_font("sans", max(8, round(size * 0.27)))
    lh = lambda f: sum(f.getmetrics())
    avail = max(20, el["w"] - size - gap)

    icons.draw_icon(draw, kind, x, y, size, fg, bg, night)
    tx, ty = x + size + gap, y
    draw.text((tx, ty), f"{round(temp)}°" if temp is not None else "--°", font=big, fill=fg, anchor="la")
    ty += lh(big)
    lines = []
    if el["show_range"] and today.get("min") is not None and today.get("max") is not None:
        lines.append(f"{round(today['min'])}° / {round(today['max'])}°")
    if el["show_text"]:
        lines.append(cond if data else "sem dados")
    for line in lines:
        draw.text((tx, ty), _ellipsize(small, line, avail), font=small, fill=fg, anchor="la")
        ty += lh(small)
    return {"x": x, "y": y, "w": el["w"], "h": max(size, ty - y)}


def _wrap(text, font, max_w, max_lines):
    """Quebra o texto em linhas que cabem em max_w (respeita \n e palavras longas)."""
    lines = []
    for para in text.split("\n"):
        cur = ""
        for word in para.split(" "):
            trial = f"{cur} {word}" if cur else word
            if font.getlength(trial) <= max_w:
                cur = trial
                continue
            if cur:
                lines.append(cur)
            while len(word) > 1 and font.getlength(word) > max_w:
                k = len(word)
                while k > 1 and font.getlength(word[:k]) > max_w:
                    k -= 1
                lines.append(word[:k])
                word = word[k:]
            cur = word
        lines.append(cur)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        last = lines[-1]
        while last and font.getlength(last + "…") > max_w:
            last = last[:-1]
        lines[-1] = last.rstrip() + "…"
    return lines


def _draw_bubble(draw, el, text, fg, bg):
    """Balão de fala com cauda opcional (aponta para onde o mascote ficará)."""
    font = get_font(el["font"], el["size"])
    pad, tail_h = 4, 6
    try:
        ascent, descent = font.getmetrics()
        line_h = ascent + descent
    except Exception:
        line_h = el["size"] + 3
    lines = _wrap(text, font, el["w"] - 2 * pad, el["max_lines"])
    x, y, w = el["x"], el["y"], el["w"]
    h = len(lines) * line_h + 2 * pad

    draw.rounded_rectangle([x, y, x + w - 1, y + h - 1], radius=5, fill=bg, outline=fg)
    if el["tail"]:
        draw.polygon([(x + 12, y + h - 1), (x + 22, y + h - 1), (x + 12, y + h - 1 + tail_h)],
                     fill=bg, outline=fg)
        draw.line([(x + 13, y + h - 1), (x + 21, y + h - 1)], fill=bg)  # apaga a borda sob a cauda
    for i, line in enumerate(lines):
        draw.text((x + pad, y + pad + i * line_h), line, font=font, fill=fg, anchor="la")
    return {"x": x, "y": y, "w": w, "h": h + (tail_h if el["tail"] else 0)}


def render(cfg, now=None):
    """Devolve (imagem 1 bit na orientação de leitura, caixas dos elementos)."""
    now = now or dt.datetime.now()
    now = now + dt.timedelta(minutes=cfg["time"]["offset_min"])
    fg, bg = (1, 0) if cfg["invert"] else (0, 1)

    canvas = Image.new("1", (W, H), bg)
    draw = ImageDraw.Draw(canvas)
    boxes = {}

    im = cfg["image"]
    if im["enabled"] and im["file"]:
        pic = load_picture(im, bool(bg))
        if pic is not None:
            canvas.paste(pic, (im["x"], im["y"]))
            boxes["image"] = {"x": im["x"], "y": im["y"], "w": im["w"], "h": im["h"]}

    if cfg["date"]["enabled"]:
        boxes["date"] = _draw_text(draw, cfg["date"], format_date(now, cfg["date"]["format"]), fg, bg)
    if cfg["time"]["enabled"]:
        boxes["time"] = _draw_text(draw, cfg["time"], format_time(now, cfg["time"]["format"]), fg, bg)

    for i, el in enumerate(cfg["texts"]):
        if el["enabled"]:
            boxes[f"text:{i}"] = _draw_textbox(canvas, el, fg, bg)

    if cfg["weatherbox"]["enabled"]:
        data = weather.usable(cfg["weather"])
        boxes["weatherbox"] = _draw_weatherbox(draw, cfg["weatherbox"], data, fg, bg)

    if cfg["mascot"]["enabled"]:
        boxes["mascot"] = _draw_bubble(draw, cfg["mascot"], mascot.current_text(cfg), fg, bg)

    return canvas, boxes


def to_panel(img, rotation):
    """Aplica a rotação física (0 ou 180) antes de enviar ao painel."""
    return img.rotate(180) if rotation == 180 else img


def to_data_url(img):
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
