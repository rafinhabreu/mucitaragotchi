"""Desenha a tela (250x122, 1 bit) a partir da configuração.

A mesma imagem alimenta a prévia no navegador e o painel e-ink,
então o que você vê no simulador é exatamente o que vai para a tela.
"""
import base64
import datetime as dt
import io
import math
import os
from functools import lru_cache

from PIL import Image, ImageDraw, ImageFont, ImageOps

import config

W, H = config.W, config.H
RESAMPLE = getattr(Image, "Resampling", Image).LANCZOS

_DEJAVU = "/usr/share/fonts/truetype/dejavu/"
FONT_FILES = {
    "sans": "DejaVuSans.ttf",
    "sans-bold": "DejaVuSans-Bold.ttf",
    "mono": "DejaVuSansMono-Bold.ttf",
    "serif": "DejaVuSerif.ttf",
}

WEEKDAYS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
MONTHS = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho",
          "agosto", "setembro", "outubro", "novembro", "dezembro"]


@lru_cache(maxsize=32)
def get_font(name, size):
    path = _DEJAVU + FONT_FILES.get(name, FONT_FILES["sans"])
    try:
        return ImageFont.truetype(path, size)
    except OSError:
        try:
            return ImageFont.load_default(size)  # Pillow >= 10.1
        except TypeError:
            return ImageFont.load_default()


def format_time(now, fmt):
    if fmt == "12h":
        return f"{now.hour % 12 or 12}:{now.minute:02d} {'AM' if now.hour < 12 else 'PM'}"
    return f"{now.hour:02d}:{now.minute:02d}"


def format_date(now, fmt):
    wd, mo = WEEKDAYS[now.weekday()], MONTHS[now.month - 1]
    if fmt == "dm":
        return f"{now.day:02d}/{now.month:02d}"
    if fmt == "long":
        return f"{wd[:3]}, {now.day} {mo[:3]} {now.year}"
    if fmt == "full":
        return f"{wd}, {now.day} de {mo}"
    return f"{now.day:02d}/{now.month:02d}/{now.year}"


@lru_cache(maxsize=6)
def _picture(path, mtime, w, h, fit, mode, threshold, bg_white):
    """Carrega, redimensiona e converte a imagem para 1 bit (com cache)."""
    img = ImageOps.exif_transpose(Image.open(path))
    if img.mode in ("RGBA", "LA", "P"):
        rgba = img.convert("RGBA")
        base = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        img = Image.alpha_composite(base, rgba)
    img = ImageOps.autocontrast(img.convert("L"))

    if fit == "cover":
        img = ImageOps.fit(img, (w, h), RESAMPLE)
    elif fit == "contain":
        img = ImageOps.contain(img, (w, h), RESAMPLE)
        base = Image.new("L", (w, h), 255 if bg_white else 0)
        base.paste(img, ((w - img.width) // 2, (h - img.height) // 2))
        img = base
    else:
        img = img.resize((w, h), RESAMPLE)

    if mode == "threshold":
        img = img.point(lambda p: 255 if p >= threshold else 0)
    return img.convert("1")  # pontilhado Floyd–Steinberg quando não é limiar


def load_picture(im, bg_white):
    path = config.IMAGES / os.path.basename(im["file"])
    try:
        return _picture(str(path), path.stat().st_mtime_ns, im["w"], im["h"],
                        im["fit"], im["mode"], im["threshold"], bg_white)
    except Exception:
        return None


def _draw_text(draw, el, text, fg, bg):
    font = get_font(el["font"], el["size"])
    try:
        # Altura estável: do topo de "Á" até o fundo de "g", para a caixa não
        # "pular" quando o texto muda.
        _, top, _, bottom = font.getbbox("Ág0", anchor="la")
        width = int(math.ceil(font.getlength(text)))
    except Exception:
        top, bottom, width = 0, el["size"], len(text) * el["size"] // 2
    height = bottom - top
    x, y = el["x"], el["y"]
    if el["backdrop"]:
        draw.rectangle([x - 3, y - 2, x + width + 2, y + height + 1], fill=bg)
    draw.text((x, y - top), text, font=font, fill=fg, anchor="la")
    return {"x": x, "y": y, "w": width, "h": height}


def render(cfg, now=None):
    """Devolve (imagem 1 bit na orientação de leitura, caixas dos elementos)."""
    now = now or dt.datetime.now()
    now = now + dt.timedelta(minutes=cfg["time"]["offset_min"])
    fg, bg = (1, 0) if cfg["invert"] else (0, 1)

    canvas = Image.new("1", (W, H), bg)
    draw = ImageDraw.Draw(canvas)
    boxes = {}

    im = cfg["image"]
    if im["enabled"] and im["file"]:
        pic = load_picture(im, bool(bg))
        if pic is not None:
            canvas.paste(pic, (im["x"], im["y"]))
            boxes["image"] = {"x": im["x"], "y": im["y"], "w": im["w"], "h": im["h"]}

    if cfg["date"]["enabled"]:
        boxes["date"] = _draw_text(draw, cfg["date"], format_date(now, cfg["date"]["format"]), fg, bg)
    if cfg["time"]["enabled"]:
        boxes["time"] = _draw_text(draw, cfg["time"], format_time(now, cfg["time"]["format"]), fg, bg)

    return canvas, boxes


def to_panel(img, rotation):
    """Aplica a rotação física (0 ou 180) antes de enviar ao painel."""
    return img.rotate(180) if rotation == 180 else img


def to_data_url(img):
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
