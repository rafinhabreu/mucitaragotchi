#!/bin/sh
# Roda a cada minuto (timer do systemd):
#  1) registra a saúde do Pi em /var/log/tamagotchi-health.log (útil para descobrir
#     a causa de um travamento: veja a última linha antes dele);
#  2) mantém a economia de energia do Wi-Fi desligada;
#  3) se a rede cair, tenta se recuperar: 3 min -> reinicia o Wi-Fi,
#     6 min -> reinicia o serviço de rede, 12 min -> reinicia o Pi (no máximo 1x por hora).
LOG="${HEALTH_LOG:-/var/log/tamagotchi-health.log}"
STATE="${HEALTH_STATE:-/run/tamagotchi-netfail}"
DRY="${HEALTH_DRYRUN:-0}"

run() { if [ "$DRY" = 1 ]; then echo "DRYRUN: $*"; else "$@"; fi; }

ts=$(date '+%F %T')
load=$(cut -d' ' -f1 /proc/loadavg)
memfree=$(awk '/MemAvailable/ {printf "%d", $2/1024}' /proc/meminfo)
swapused=$(awk '/SwapTotal/ {t=$2} /SwapFree/ {f=$2} END {printf "%d", (t-f)/1024}' /proc/meminfo)
temp=$(vcgencmd measure_temp 2>/dev/null | cut -d= -f2)
thr=$(vcgencmd get_throttled 2>/dev/null | cut -d= -f2)
sig=$(iw dev wlan0 link 2>/dev/null | awk '/signal:/ {print $2}')
svc=$(systemctl is-active tamagotchi 2>/dev/null)
up="${HEALTH_UP:-$(cut -d. -f1 /proc/uptime)}"
gw="${HEALTH_GW:-$(ip route 2>/dev/null | awk '/^default/ {print $3; exit}')}"

ok=0
if [ -n "$gw" ] && ping -c1 -W3 "$gw" >/dev/null 2>&1; then ok=1; fi

echo "$ts load=$load memfree=${memfree}MB swapused=${swapused}MB temp=${temp:-?} throttled=${thr:-?} wifi_dbm=${sig:-?} gw_ok=$ok svc=${svc:-?} up=${up}s" >> "$LOG"
if [ "$(wc -c < "$LOG")" -gt 400000 ]; then
  tail -n 1500 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
fi

[ "$DRY" = 1 ] || iw dev wlan0 set power_save off >/dev/null 2>&1 || true

if [ "$ok" = 1 ]; then
  rm -f "$STATE"
  exit 0
fi

n=$(( $(cat "$STATE" 2>/dev/null || echo 0) + 1 ))
echo "$n" > "$STATE"

if [ "$n" -eq 3 ]; then
  logger -t tamagotchi-health "sem rede há 3 min: reiniciando o Wi-Fi"
  if command -v nmcli >/dev/null 2>&1; then
    run nmcli radio wifi off; sleep 2; run nmcli radio wifi on
  else
    run ip link set wlan0 down; sleep 2; run ip link set wlan0 up
  fi
fi

if [ "$n" -eq 6 ]; then
  logger -t tamagotchi-health "sem rede há 6 min: reiniciando o serviço de rede"
  run systemctl restart NetworkManager 2>/dev/null \
    || run systemctl restart wpa_supplicant 2>/dev/null \
    || run systemctl restart dhcpcd 2>/dev/null || true
fi

if [ "$n" -ge 12 ] && [ "$up" -gt 3600 ]; then
  logger -t tamagotchi-health "sem rede há $n min: reiniciando o Pi"
  run systemctl reboot
fi
