"""Controle do painel Waveshare 2.13" V4 e atualização em segundo plano.

- Ao clicar em "Aplicar": atualização completa imediata.
- A cada virada de minuto: atualização parcial (só se a imagem mudou).
- A cada FULL_REFRESH_EVERY parciais: uma completa, para evitar "fantasmas".
- Sem a biblioteca da Waveshare (ou com EPD_MOCK=1) roda em modo simulação
  e grava o quadro em data/last_frame.png.
"""
import os
import sys
import threading
import time
from pathlib import Path

import config
import renderer

EPD_LIB = os.environ.get(
    "EPD_LIB", str(Path.home() / "e-Paper/RaspberryPi_JetsonNano/python/lib")
)
FULL_REFRESH_EVERY = int(os.environ.get("FULL_REFRESH_EVERY", "20"))


class Panel:
    def __init__(self):
        self.epd = None
        self.note = ""
        if os.environ.get("EPD_MOCK") == "1":
            self.note = "EPD_MOCK=1"
            return
        try:
            sys.path.insert(0, EPD_LIB)
            from waveshare_epd import epd2in13_V4
            self.epd = epd2in13_V4.EPD()
        except Exception as e:  # biblioteca ausente, SPI desligado etc.
            self.note = f"{type(e).__name__}: {e}"

    @property
    def mock(self):
        return self.epd is None

    def _save(self, img):
        config.DATA.mkdir(parents=True, exist_ok=True)
        img.save(config.DATA / "last_frame.png")

    def full(self, img, clear=False):
        if self.mock:
            return self._save(img)
        self.epd.init()
        if clear:
            self.epd.Clear(0xFF)
        # Atualização completa que também grava a base para as parciais
        self.epd.displayPartBaseImage(self.epd.getbuffer(img))

    def partial(self, img):
        if self.mock:
            return self._save(img)
        self.epd.displayPartial(self.epd.getbuffer(img))

    def sleep(self):
        if not self.mock:
            try:
                self.epd.sleep()
            except Exception:
                pass


class Worker(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.panel = Panel()
        self.cv = threading.Condition()
        self.io = threading.Lock()
        self.job = self.taken = self.done = 0
        self.want_full = self.want_clear = False
        self.stopping = False
        self.updating = False
        self.error = None
        self.last_update = None
        self.last_frame = None
        self.partials = 0

    # --- chamadas vindas do servidor web -------------------------------
    def request(self, full=True, clear=False):
        with self.cv:
            self.job += 1
            self.want_full |= full
            self.want_clear |= clear
            self.cv.notify_all()
            return self.job

    def status(self):
        return {
            "done": self.done,
            "updating": self.updating,
            "error": self.error,
            "mock": self.panel.mock,
            "note": self.panel.note,
            "last_update": self.last_update,
        }

    def shutdown(self):
        with self.cv:
            self.stopping = True
            self.cv.notify_all()
        with self.io:
            self.panel.sleep()

    # --- laço principal --------------------------------------------------
    def run(self):
        self.request(full=True)  # primeira imagem ao ligar
        while True:
            with self.cv:
                if self.job == self.taken and not self.stopping:
                    # acorda 0,3 s depois da virada do minuto
                    self.cv.wait(timeout=60.3 - (time.time() % 60))
                if self.stopping:
                    return
                forced = self.job != self.taken
                job, full, clear = self.job, self.want_full, self.want_clear
                self.taken = job
                self.want_full = self.want_clear = False
            self._update(job, forced, full, clear)

    def _update(self, job, forced, full, clear):
        try:
            cfg = config.load()
            img, _ = renderer.render(cfg)
            frame = renderer.to_panel(img, cfg["rotation"])
            data = frame.tobytes()
            if not forced and data == self.last_frame:
                return  # nada mudou: e-ink não precisa gastar atualização

            self.updating = True
            do_full = (
                (forced and full) or clear or self.last_frame is None
                or self.partials >= FULL_REFRESH_EVERY
            )
            with self.io:
                if do_full:
                    self.panel.full(frame, clear=clear)
                    self.partials = 0
                else:
                    self.panel.partial(frame)
                    self.partials += 1
            self.last_frame = data
            self.last_update = time.strftime("%H:%M")
            self.error = None
        except Exception as e:
            self.error = f"{type(e).__name__}: {e}"
            self.last_frame = None  # força atualização completa na próxima
        finally:
            self.updating = False
            if forced:
                self.done = job
