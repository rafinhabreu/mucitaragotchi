#!/usr/bin/env bash
# Instala as dependências e deixa o Tamagotchi rodando como serviço (inicia no boot).
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
USER_NAME="$(id -un)"

sudo apt-get update
sudo apt-get install -y python3-flask python3-pil python3-numpy python3-spidev python3-gpiozero fonts-dejavu

sed -e "s|__USER__|$USER_NAME|g" -e "s|__DIR__|$DIR|g" "$DIR/tamagotchi.service" \
  | sudo tee /etc/systemd/system/tamagotchi.service >/dev/null

sudo systemctl daemon-reload
sudo systemctl enable --now tamagotchi.service

echo
echo "Pronto! Abra no navegador: http://$(hostname).local:8080"
echo "Logs:  journalctl -u tamagotchi -f"
