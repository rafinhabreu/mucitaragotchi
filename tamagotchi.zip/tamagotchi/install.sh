#!/usr/bin/env bash
# Instala (ou atualiza) o Tamagotchi como serviço que inicia no boot.
# Pode rodar de novo a cada atualização: não mexe em data/ (config, imagens, chaves).
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
USER_NAME="$(id -un)"

sudo apt-get update
sudo apt-get install -y python3-flask python3-waitress python3-pil python3-numpy \
  python3-spidev python3-gpiozero fonts-dejavu iw

sed -e "s|__USER__|$USER_NAME|g" -e "s|__DIR__|$DIR|g" "$DIR/tamagotchi.service" \
  | sudo tee /etc/systemd/system/tamagotchi.service >/dev/null

bash "$DIR/harden.sh"

sudo systemctl daemon-reload
sudo systemctl enable tamagotchi.service
sudo systemctl restart tamagotchi.service

echo
echo "Pronto! Abra no navegador: http://$(hostname).local:8080"
echo "Logs do app:   journalctl -u tamagotchi -f"
