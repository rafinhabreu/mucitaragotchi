"""Motor de fala do Jorginho: escolhe o que ele diz e quando.

O estado (mensagem atual) fica em data/mascot_state.json, então a prévia no
navegador e a tela mostram sempre a mesma fala, mesmo após reiniciar o Pi.
"""
import datetime as dt
import json
import os
import random
import threading
import time

import config
import icons
import phrases
import weather

STATE_FILE = config.DATA / "mascot_state.json"
REVEAL_AFTER = 50      # segundos até a resposta da piada (aparece no minuto seguinte)
HOLD_AFTER_SPEAK = 300  # depois de "Falar agora", ignora o horário de silêncio por 5 min
RECENT = 12            # quantas falas recentes evitar repetir

_lock = threading.Lock()


# --- estado ---------------------------------------------------------------------------
def _load():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save(st):
    config.DATA.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False)
    os.replace(tmp, STATE_FILE)


# --- conteúdo ---------------------------------------------------------------------------
def _slot(hour):
    if 5 <= hour < 12:
        return "manha"
    if 12 <= hour < 18:
        return "tarde"
    if 18 <= hour < 23:
        return "noite"
    return "madrugada"


def weather_messages(w):
    """Frases geradas a partir dos dados reais de clima."""
    out = []
    cur, today, tmr = w.get("current"), w.get("today"), w.get("tomorrow")
    r = lambda v: int(round(v))

    if cur and cur.get("temp") is not None:
        t = cur["temp"]
        cond = (cur.get("text") or "").lower()
        if today and today.get("min") is not None and today.get("max") is not None:
            lead = f"Agora faz {r(t)}°" + (f" ({cond})" if cond else "")
            out.append(f"{lead}. Hoje: mín {r(today['min'])}°, máx {r(today['max'])}°.")
        else:
            out.append(f"Agora faz {r(t)}°" + (f" e o tempo está {cond}." if cond else "."))
        feels = cur.get("feels")
        if feels is not None and abs(feels - t) >= 4:
            out.append(f"Faz {r(t)}°, mas a sensação térmica é de {r(feels)}°.")
        if cur.get("raining"):
            out.append("Está chovendo agora! Se for sair, leva guarda-chuva.")
        if t >= 30:
            out.append(f"{r(t)}° lá fora! Água, sombra e pouca pressa.")
        if t <= 12:
            out.append(f"{r(t)}° lá fora. Hora de pegar um casaco!")

    if today:
        p, lo, hi = today.get("rain_prob"), today.get("min"), today.get("max")
        if p is not None and p >= 50:
            out.append(f"{r(p)}% de chance de chuva hoje. Leva o guarda-chuva!")
        elif p is not None and p >= 30:
            out.append(f"Pode chover hoje ({r(p)}%). Melhor garantir um guarda-chuva.")
        elif p is not None and p < 20 and hi is not None:
            out.append(f"Sem chuva à vista hoje. Máxima de {r(hi)}°.")
        if hi is not None and hi >= 32:
            out.append(f"Máxima de {r(hi)}° hoje. Hidrata aí!")
        if lo is not None and lo <= 12:
            out.append(f"Mínima de {r(lo)}° hoje. Cuidado com o friozinho.")

    if tmr and tmr.get("max") is not None and tmr.get("min") is not None:
        txt = (tmr.get("text") or "").lower()
        line = f"Amanhã: {r(tmr['min'])}° a {r(tmr['max'])}°" + (f", {txt}." if txt else ".")
        out.append(line)
        if tmr.get("rain_prob") is not None and tmr["rain_prob"] >= 60:
            out.append(f"Amanhã tem {r(tmr['rain_prob'])}% de chance de chuva. Separa o guarda-chuva!")
    return out


_BY_KIND = {
    "sun": ["Que dia lindo de sol! Aproveita pra abrir a janela.",
            "Solzão lá fora! Protetor solar, hein?",
            "Céu aberto hoje. Bom dia pra uma caminhada!"],
    "partly": ["Sol com nuvenzinhas: o tempo não se decidiu, mas está agradável.",
               "Meio sol, meio nuvem. Leva um casaquinho só por garantia."],
    "cloud": ["Dia nublado: ótimo para um café e muito foco.",
              "Nublado lá fora, mas aqui dentro está tudo em ordem."],
    "rain": ["Olha a chuva! Se for sair, sai preparado.",
             "Dia de chuva: bom para um chá e uma boa música.",
             "Guarda-chuva na mão, que o tempo está molhado!"],
    "storm": ["Trovoada à vista! Salva o trabalho e evita ficar na rua.",
              "Tempestade por aí. Melhor ficar em casa, tá?"],
    "snow": ["Neve! Agasalha bem e cuidado ao sair."],
    "fog": ["Neblina lá fora. Se for dirigir, redobra a atenção."],
}


def weather_comments(w):
    """Comentários SOBRE o clima mostrado na tela (quase sem repetir os números dele)."""
    cur, today, tmr = w.get("current") or {}, w.get("today") or {}, w.get("tomorrow") or {}
    kind = icons.classify(cur.get("text") or today.get("text"), cur.get("icon_id") or today.get("icon_id"))
    if cur.get("raining") and kind not in ("rain", "storm"):
        kind = "rain"
    out = list(_BY_KIND.get(kind, []))

    t, lo, hi = cur.get("temp"), today.get("min"), today.get("max")
    p = today.get("rain_prob")
    if p is not None and p >= 40 and kind not in ("rain", "storm"):
        out.append("Tem chance de chuva hoje, como a tela mostra. Leva o guarda-chuva, vai que...")
    if (hi is not None and hi >= 32) or (t is not None and t >= 30):
        out.append("Tá quente! Água, sombra e roupa leve.")
    if (lo is not None and lo <= 12) or (t is not None and t <= 12):
        out.append("Friozinho hoje. Vai de casaco!")
    if lo is not None and hi is not None and hi - lo >= 12:
        out.append("A temperatura varia bastante hoje. Veste em camadas!")
    feels = cur.get("feels")
    if t is not None and feels is not None and abs(feels - t) >= 4:
        out.append("A sensação térmica está acima do termômetro." if feels > t
                   else "A sensação térmica está mais baixa do que o termômetro mostra.")
    if tmr.get("max") is not None and hi is not None:
        if tmr["max"] - hi >= 4:
            out.append("Amanhã vai esquentar mais que hoje.")
        elif hi - tmr["max"] >= 4:
            out.append("Amanhã esfria. Deixa o casaco à mão.")
    if tmr.get("rain_prob") is not None and tmr["rain_prob"] >= 60:
        out.append("Amanhã promete chuva. Já separa o guarda-chuva!")
    return out


def _pools(cfg, now):
    m = cfg["mascot"]
    name = m["name"]
    fill = lambda lst: [s.replace("{nome}", name) for s in lst]
    custom = fill(m["custom"])

    pools = {}
    if m["kinds"]["comment"]:
        pool = fill(phrases.COMMENTS) + fill(phrases.BY_SLOT[_slot(now.hour)])
        pool += fill(phrases.BY_WEEKDAY.get(now.weekday(), []))
        pool += [c for c in custom if "|" not in c]
        pools["comment"] = pool
    if m["kinds"]["joke"]:
        pools["joke"] = fill(phrases.JOKES) + [c for c in custom if "|" in c]
    if m["kinds"]["weather"]:
        data = weather.usable(cfg["weather"])
        if not data:
            msgs = []
        elif cfg["weatherbox"]["enabled"]:
            msgs = weather_comments(data)  # os números já estão na tela: ele só comenta
        else:
            msgs = weather_messages(data) + weather_comments(data)
        if msgs:
            pools["weather"] = msgs
    if not pools:  # nenhuma categoria ligada: comentários básicos
        pools["comment"] = fill(phrases.COMMENTS)
    return pools


def _new_message(cfg, now, st, kind=None):
    """Sorteia a próxima fala. Lança ValueError se a categoria pedida não existe."""
    pools = _pools(cfg, now)
    if kind is not None and kind not in pools:
        raise ValueError(
            "Ainda não tenho dados de clima. Escolha a cidade, clique em Aplicar e "
            "aguarde alguns segundos." if kind == "weather"
            else "Essa categoria está desligada nas configurações do Jorginho."
        )
    if kind is None:
        options = [k for k in pools if k != st.get("kind")] or list(pools)
        kind = random.choice(options)
    recent = st.get("recent", [])
    pool = [p for p in pools[kind] if p not in recent] or pools[kind]
    text = random.choice(pool)

    now_ts = now.timestamp()
    st["kind"], st["at"] = kind, now_ts
    if "|" in text:
        question, answer = text.split("|", 1)
        st.update(text=question.strip(), reveal=answer.strip(), reveal_at=now_ts + REVEAL_AFTER)
    else:
        st.update(text=text, reveal="", reveal_at=0)
    st["recent"] = (recent + [text])[-RECENT:]
    return st


def _sleep_message(cfg, st, now):
    text = random.choice(phrases.SLEEP).replace("{nome}", cfg["mascot"]["name"])
    st.update(kind="sleep", text=text, reveal="", reveal_at=0, at=now.timestamp())
    return st


def in_quiet(m, hour):
    q = m["quiet"]
    if not q["enabled"] or q["start"] == q["end"]:
        return False
    if q["start"] < q["end"]:
        return q["start"] <= hour < q["end"]
    return hour >= q["start"] or hour < q["end"]


# --- API usada pelo resto do sistema ------------------------------------------------------
def current_text(cfg, now=None):
    """Fala atual (cria a primeira se ainda não existir). Não avança sozinha."""
    now = now or dt.datetime.now()
    with _lock:
        st = _load()
        if not st.get("text"):
            _save(_new_message(cfg, now, st))
        return st["text"]


def tick(cfg, now=None):
    """Chamado a cada minuto: troca a fala, revela a piada ou dorme. True se mudou."""
    m = cfg["mascot"]
    if not m["enabled"]:
        return False
    now = now or dt.datetime.now()
    t = now.timestamp()
    with _lock:
        st = _load()
        if not st.get("text"):
            _save(_new_message(cfg, now, st))
            return True
        quiet = in_quiet(m, now.hour) and t >= st.get("hold_until", 0)
        if quiet:
            if st.get("kind") == "sleep":
                return False
            _save(_sleep_message(cfg, st, now))
            return True
        if st.get("reveal") and t >= st.get("reveal_at", 0):
            st["text"] = f"{st['text']}\n{st['reveal']}"
            st["reveal"] = ""
            _save(st)
            return True
        if st.get("kind") == "sleep" or t - st.get("at", 0) >= m["interval_min"] * 60:
            _save(_new_message(cfg, now, st))
            return True
    return False


def speak(cfg, kind=None, now=None):
    """O usuário pediu: o Jorginho fala agora (mesmo no horário de silêncio)."""
    now = now or dt.datetime.now()
    with _lock:
        st = _load()
        _new_message(cfg, now, st, kind)
        st["hold_until"] = now.timestamp() + HOLD_AFTER_SPEAK
        _save(st)
        return {"kind": st["kind"], "text": st["text"]}
