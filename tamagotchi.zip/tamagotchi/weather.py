"""Clima para o Jorginho.

Duas fontes, mesma saída normalizada:
- AccuWeather: precisa de chave (teste de 14 dias; depois plano pago).
- Open-Meteo: gratuita para uso não comercial e sem chave.

Tudo fica em cache em disco e as chamadas à AccuWeather são contadas, com um
teto diário configurável, para você nunca estourar o plano sem perceber.
"""
import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import config

ACCU_BASE = os.environ.get("ACCUWEATHER_BASE", "https://dataservice.accuweather.com")
METEO_BASE = os.environ.get("OPENMETEO_BASE", "https://api.open-meteo.com")
GEO_BASE = os.environ.get("OPENMETEO_GEO_BASE", "https://geocoding-api.open-meteo.com")

DAILY_CAP = int(os.environ.get("ACCUWEATHER_DAILY_CAP", "100"))  # teto de segurança
CURRENT_EVERY = 60 * 60          # condições atuais: 1x por hora
FORECAST_EVERY = 6 * 60 * 60     # previsão dos próximos dias: a cada 6 h
METEO_EVERY = 30 * 60            # Open-Meteo traz tudo numa chamada só
ERROR_BACKOFF = 10 * 60          # após um erro, espera 10 min antes de tentar de novo
MAX_AGE = 8 * 60 * 60            # dados mais velhos que isso não viram frase

SECRETS_FILE = config.DATA / "secrets.json"
CACHE_FILE = config.DATA / "weather_cache.json"
USAGE_FILE = config.DATA / "weather_usage.json"

_cache_lock = threading.Lock()
_usage_lock = threading.Lock()
_refresh_lock = threading.Lock()


class WeatherError(Exception):
    """Erro com mensagem já pronta para mostrar ao usuário."""


# --- chave da API (nunca volta para o navegador) ----------------------------
def get_key():
    env = os.environ.get("ACCUWEATHER_API_KEY", "").strip()
    if env:
        return env
    try:
        with open(SECRETS_FILE, "r", encoding="utf-8") as f:
            return str(json.load(f).get("accuweather_key", "")).strip()
    except (OSError, ValueError):
        return ""


def set_key(key):
    key = (key or "").strip()
    if len(key) < 8 or any(c.isspace() for c in key):
        raise ValueError("Essa chave não parece válida (sem espaços, mínimo de 8 caracteres).")
    config.DATA.mkdir(parents=True, exist_ok=True)
    tmp = SECRETS_FILE.with_suffix(".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({"accuweather_key": key}, f)
    os.replace(tmp, SECRETS_FILE)


# --- HTTP ----------------------------------------------------------------------
def _http_message(code):
    if code == 401:
        return "A AccuWeather recusou a chave (inválida, inativa ou teste expirado)."
    if code == 403:
        return "O plano da sua chave da AccuWeather não inclui esse recurso."
    if code in (429, 503):
        return "Limite de chamadas da AccuWeather atingido (ou serviço fora do ar)."
    return f"O serviço de clima respondeu com erro {code}."


def _get(url, headers=None, timeout=10):
    req = urllib.request.Request(
        url, headers={"User-Agent": "tamagotchi-eink/2", "Accept": "application/json", **(headers or {})}
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise WeatherError(_http_message(e.code)) from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise WeatherError("Sem conexão com o serviço de clima.") from None
    except ValueError:
        raise WeatherError("Resposta inesperada do serviço de clima.") from None


# --- orçamento de chamadas (AccuWeather) -------------------------------------
def _read_usage():
    try:
        with open(USAGE_FILE, "r", encoding="utf-8") as f:
            u = json.load(f)
    except (OSError, ValueError):
        u = {}
    today = time.strftime("%Y-%m-%d")
    if u.get("day") != today:
        u["day"], u["calls"] = today, 0
    if u.get("month") != today[:7]:
        u["month"], u["month_calls"] = today[:7], 0
    u.setdefault("calls", 0)
    u.setdefault("month_calls", 0)
    return u


def _spend():
    with _usage_lock:
        u = _read_usage()
        if u["calls"] >= DAILY_CAP:
            raise WeatherError(
                f"Teto diário de {DAILY_CAP} chamadas à AccuWeather atingido. Volta amanhã."
            )
        u["calls"] += 1
        u["month_calls"] += 1
        config.DATA.mkdir(parents=True, exist_ok=True)
        with open(USAGE_FILE, "w", encoding="utf-8") as f:
            json.dump(u, f)


def _accu(path, **params):
    key = get_key()
    if not key:
        raise WeatherError("Salve a chave da AccuWeather primeiro.")
    _spend()
    url = f"{ACCU_BASE}{path}?{urllib.parse.urlencode(params)}"
    return _get(url, headers={"Authorization": f"Bearer {key}"})


# --- AccuWeather --------------------------------------------------------------------
def accu_search(q):
    data = _accu("/locations/v1/cities/search", q=q, language="pt-br")
    out = []
    for r in data[:8]:
        out.append({
            "key": str(r.get("Key", "")),
            "name": r.get("LocalizedName") or r.get("EnglishName") or "?",
            "area": (r.get("AdministrativeArea") or {}).get("LocalizedName", ""),
            "country": (r.get("Country") or {}).get("LocalizedName", ""),
        })
    return [r for r in out if r["key"]]


def accu_current(key):
    data = _accu(f"/currentconditions/v1/{key}", language="pt-br", details="true")
    d = data[0] if isinstance(data, list) and data else {}
    temp = ((d.get("Temperature") or {}).get("Metric") or {}).get("Value")
    if temp is None:
        raise WeatherError("A AccuWeather não devolveu a temperatura atual.")
    return {
        "temp": temp,
        "feels": ((d.get("RealFeelTemperature") or {}).get("Metric") or {}).get("Value"),
        "text": d.get("WeatherText") or "",
        "raining": bool(d.get("HasPrecipitation")),
        "icon_id": d.get("WeatherIcon"),
        "is_day": d.get("IsDayTime", True) is not False,
    }


def accu_forecast(key):
    data = _accu(f"/forecasts/v1/daily/5day/{key}", language="pt-br", details="true", metric="true")
    days = []
    for d in (data.get("DailyForecasts") or [])[:2]:
        t = d.get("Temperature") or {}
        day = d.get("Day") or {}
        days.append({
            "min": (t.get("Minimum") or {}).get("Value"),
            "max": (t.get("Maximum") or {}).get("Value"),
            "text": day.get("ShortPhrase") or day.get("IconPhrase") or day.get("LongPhrase") or "",
            "rain_prob": day.get("PrecipitationProbability"),
            "icon_id": day.get("Icon"),
        })
    if not days:
        raise WeatherError("A AccuWeather não devolveu a previsão.")
    return days[0], (days[1] if len(days) > 1 else None)


# --- Open-Meteo ----------------------------------------------------------------------
WMO = {
    0: "céu limpo", 1: "predominantemente limpo", 2: "parcialmente nublado", 3: "nublado",
    45: "neblina", 48: "neblina", 51: "garoa fraca", 53: "garoa", 55: "garoa forte",
    56: "garoa congelante", 57: "garoa congelante", 61: "chuva fraca", 63: "chuva",
    65: "chuva forte", 66: "chuva congelante", 67: "chuva congelante", 71: "neve fraca",
    73: "neve", 75: "neve forte", 77: "grãos de neve", 80: "pancadas de chuva fracas",
    81: "pancadas de chuva", 82: "pancadas de chuva fortes", 85: "pancadas de neve",
    86: "pancadas de neve", 95: "tempestade", 96: "tempestade com granizo",
    99: "tempestade com granizo",
}
RAIN_CODES = {51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82, 95, 96, 99}


def meteo_search(q):
    qs = urllib.parse.urlencode({"name": q, "count": 8, "language": "pt", "format": "json"})
    data = _get(f"{GEO_BASE}/v1/search?{qs}")
    out = []
    for r in data.get("results") or []:
        try:
            key = f"{float(r['latitude']):.4f},{float(r['longitude']):.4f}"
        except (KeyError, TypeError, ValueError):
            continue
        out.append({"key": key, "name": r.get("name", "?"),
                    "area": r.get("admin1", ""), "country": r.get("country", "")})
    return out


def meteo_fetch(latlon):
    try:
        lat, lon = [float(v) for v in latlon.split(",")]
    except ValueError:
        raise WeatherError("Local inválido. Escolha a cidade de novo.") from None
    qs = urllib.parse.urlencode({
        "latitude": lat, "longitude": lon, "timezone": "auto", "forecast_days": 2,
        "current": "temperature_2m,apparent_temperature,weather_code,precipitation,is_day",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max",
    })
    d = _get(f"{METEO_BASE}/v1/forecast?{qs}")
    cur, daily = d.get("current") or {}, d.get("daily") or {}
    if cur.get("temperature_2m") is None:
        raise WeatherError("O Open-Meteo não devolveu a temperatura atual.")

    def day(i):
        try:
            return {
                "min": daily["temperature_2m_min"][i], "max": daily["temperature_2m_max"][i],
                "text": WMO.get(daily["weather_code"][i], ""),
                "rain_prob": daily["precipitation_probability_max"][i],
            }
        except (KeyError, IndexError, TypeError):
            return None

    code = cur.get("weather_code")
    current = {
        "temp": cur["temperature_2m"], "feels": cur.get("apparent_temperature"),
        "text": WMO.get(code, ""),
        "raining": (cur.get("precipitation") or 0) > 0 or code in RAIN_CODES,
        "is_day": cur.get("is_day", 1) != 0,
    }
    return current, day(0), day(1)


# --- busca de cidades (usada pela interface) ------------------------------------------
def search(provider, q):
    if provider == "accuweather":
        return accu_search(q)
    if provider == "openmeteo":
        return meteo_search(q)
    raise WeatherError("Fonte de clima desconhecida.")


# --- cache e atualização ------------------------------------------------------------------
def _load_cache():
    with _cache_lock:
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}


def _save_cache(cache):
    with _cache_lock:
        config.DATA.mkdir(parents=True, exist_ok=True)
        tmp = CACHE_FILE.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False)
        os.replace(tmp, CACHE_FILE)


def _tag(w):
    return f'{w["provider"]}:{w["location_key"]}'


def refresh(force=False, raise_errors=False):
    """Busca o que estiver vencido. Usa a configuração salva em disco."""
    w = config.load()["weather"]
    if not w["location_key"] or w["location_provider"] != w["provider"]:
        if raise_errors:
            raise WeatherError("Escolha uma cidade e clique em Aplicar primeiro.")
        return
    if w["provider"] == "accuweather" and not get_key():
        if raise_errors:
            raise WeatherError("Salve a chave da AccuWeather primeiro.")
        return

    with _refresh_lock:
        cache = _load_cache()
        now = time.time()
        if cache.get("tag") != _tag(w):
            cache = {"tag": _tag(w)}  # lugar novo: começa do zero
        elif not force and cache.get("error_at") and now - cache["error_at"] < ERROR_BACKOFF:
            return
        try:
            if w["provider"] == "accuweather":
                if force or now - cache.get("current_at", 0) >= CURRENT_EVERY:
                    cache["current"], cache["current_at"] = accu_current(w["location_key"]), now
                if force or now - cache.get("forecast_at", 0) >= FORECAST_EVERY:
                    cache["today"], cache["tomorrow"] = accu_forecast(w["location_key"])
                    cache["forecast_at"] = now
            elif force or now - cache.get("current_at", 0) >= METEO_EVERY:
                cache["current"], cache["today"], cache["tomorrow"] = meteo_fetch(w["location_key"])
                cache["current_at"] = cache["forecast_at"] = now
            cache["error"] = ""
            cache.pop("error_at", None)
        except WeatherError as e:
            cache["error"], cache["error_at"] = str(e), now
            _save_cache(cache)
            if raise_errors:
                raise
            return
        _save_cache(cache)


def usable(wcfg):
    """Dados recentes para a configuração atual, ou None."""
    c = _load_cache()
    if not wcfg["location_key"] or c.get("tag") != _tag(wcfg):
        return None
    ts = max(c.get("current_at", 0), c.get("forecast_at", 0))
    if time.time() - ts > MAX_AGE or not (c.get("current") or c.get("today")):
        return None
    return c


def info():
    c = _load_cache()
    u = _read_usage()
    ts = max(c.get("current_at", 0), c.get("forecast_at", 0))
    return {
        "has_key": bool(get_key()),
        "key_from_env": bool(os.environ.get("ACCUWEATHER_API_KEY", "").strip()),
        "daily_cap": DAILY_CAP,
        "calls_today": u["calls"],
        "calls_month": u["month_calls"],
        "tag": c.get("tag", ""),
        "current": c.get("current"),
        "today": c.get("today"),
        "tomorrow": c.get("tomorrow"),
        "updated": time.strftime("%H:%M", time.localtime(ts)) if ts else "",
        "error": c.get("error", ""),
    }


class Poller(threading.Thread):
    """Mantém o cache atualizado sem travar a tela nem a interface."""

    def __init__(self):
        super().__init__(daemon=True)
        self.wake = threading.Event()

    def poke(self):
        self.wake.set()

    def run(self):
        while True:
            self.wake.wait(60)
            self.wake.clear()
            try:
                refresh()
            except Exception:
                pass
