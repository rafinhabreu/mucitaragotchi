"""Frases do Jorginho. Para ampliar o repertório, basta acrescentar itens nas listas.

- {nome} é trocado pelo nome configurado do mascote.
- Piadas usam o formato "Pergunta?|Resposta": a pergunta aparece primeiro e a
  resposta chega cerca de um minuto depois.
- Mantenha cada frase curta (até ~95 caracteres) para caber no balão.
"""

COMMENTS = [
    "Já bebeu água hoje? Eu não bebo, mas torço por você!",
    "Que tal alongar um pouquinho? Seu corpo agradece.",
    "Respira fundo: inspira... expira... Pronto!",
    "Postura! Ajeita essa coluna aí.",
    "Descansa a vista: olha pela janela por 20 segundos.",
    "Você está indo bem. Eu só marco as horas, mas percebo.",
    "Pausa de 5 minutos também é produtividade.",
    "Um passo de cada vez. Eu, por exemplo, só ando de minuto em minuto.",
    "Lembra de comer alguma coisa de verdade, hein?",
    "Se der, levanta e dá uma voltinha. Eu cuido da mesa.",
    "Tá tudo sob controle por aqui. Pode confiar no {nome}.",
    "Você também precisa recarregar a bateria de vez em quando.",
    "Não esquece de sorrir. É de graça e funciona.",
    "Mesa organizada, cabeça organizada. Ou quase.",
]

BY_SLOT = {
    "manha": [
        "Bom dia! Hoje vai ser um bom dia, eu sinto.",
        "Bom dia! Café primeiro, o resto depois.",
        "Bom dia! O {nome} acordou pronto pra mais um dia.",
    ],
    "tarde": [
        "Boa tarde! Já almoçou direitinho?",
        "Boa tarde! Falta menos para o fim do expediente.",
        "Boa tarde! Hora de uma aguinha e um alongamento.",
    ],
    "noite": [
        "Boa noite! Hora de desacelerar um pouco.",
        "Boa noite! Que tal um jantar gostoso hoje?",
        "Fim de dia: você fez o que deu, e isso já basta.",
    ],
    "madrugada": [
        "Já é tarde, hein? Amanhã tem mais, vai descansar.",
        "Ainda acordado? Eu também, mas sou de plantão.",
        "Dormir cedo é um bom hábito. Fica a dica do {nome}.",
    ],
}

# 0 = segunda ... 6 = domingo
BY_WEEKDAY = {
    0: ["Segunda-feira... coragem! Eu acredito em você."],
    4: ["Sextou! Você merece, eu mereço, a mesa merece."],
    5: ["Sábado! Descansa sem culpa."],
    6: ["Domingo é dia de recarregar as energias."],
}

SLEEP = [
    "Zzz...",
    "Zzz... boa noite!",
    "Zzz... shhh, o {nome} está dormindo.",
]

JOKES = [
    "O que o pato disse para a pata?|Vem Quá!",
    "Por que o livro de matemática ficou triste?|Porque tinha muitos problemas.",
    "Qual é o café mais perigoso do mundo?|O ex-presso.",
    "O que o tomate foi fazer no banco?|Tirar extrato.",
    "Qual é o animal mais antigo do mundo?|A zebra, porque é em preto e branco.",
    "Por que o computador foi ao médico?|Porque estava com vírus.",
    "O que o zero disse para o oito?|Belo cinto!",
    "Como o elétron atende o telefone?|Próton!",
    "O que é, o que é: quanto mais se tira, maior fica?|O buraco.",
    "Por que o programador confunde Natal com Halloween?|Porque Oct 31 = Dec 25.",
    "Por que o relógio foi preso?|Porque ficava dando hora pra todo mundo.",
    "Por que a vaca foi para o espaço?|Para ver a Via Láctea.",
    "O que a e-ink disse para o LCD?|Eu seguro a imagem sem gastar energia!",
    "Qual é a diferença entre eu e o Wi-Fi?|Eu só reinicio quando você pede.",
    "Por que o Pi é irracional?|Porque nunca termina uma conversa.",
    "Qual é a sobremesa favorita do Raspberry Pi?|Torta de framboesa (pie, sacou?).",
    "Por que o jacaré tirou o filho da escola?|Porque ele réptil de ano.",
    "O que o oceano disse para a praia?|Nada, só deu uma onda.",
]
