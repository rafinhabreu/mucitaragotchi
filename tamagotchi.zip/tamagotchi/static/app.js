(() => {
  'use strict';

  const W = 250, H = 122;
  const NAMES = { time: 'Hora', date: 'Data', image: 'Imagem', mascot: 'Jorginho', weatherbox: 'Clima' };
  const TEXT_DEFAULT = { enabled: true, text: 'Olá!', x: 10, y: 10, size: 20, font: 'sans-bold',
    angle: 0, align: 'left', backdrop: false, border: false };
  const MAX_TEXTS = 8;

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const clone = o => JSON.parse(JSON.stringify(o));
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const get = (o, p) => p.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
  const set = (o, p, v) => {
    const ks = p.split('.'), last = ks.pop();
    ks.reduce((a, k) => a[k], o)[last] = v;
  };
  const jsonPost = (url, body) => fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body ?? {}),
  });

  const getEl = k => (k.startsWith('text:') ? cfg.texts[+k.slice(5)] : cfg[k]);
  const nameOf = k => (k.startsWith('text:') ? `Texto ${+k.slice(5) + 1}` : NAMES[k]);
  // 'texts.2.angle' -> 'text:2'; 'time.size' -> 'time'
  const selectionFor = path => {
    const m = path.match(/^texts\.(\d+)\./);
    if (m) return `text:${m[1]}`;
    const key = path.split('.')[0];
    return NAMES[key] ? key : null;
  };
  let recenter = null;   // mantém o centro do texto fixo enquanto gira

  let cfg = null;        // o que está sendo editado
  let applied = null;    // o que está na tela do aparelho
  let boxes = {};        // caixas dos elementos, calculadas pelo servidor
  let images = [];
  let selected = 'time';
  let scale = 2;

  /* ---------------- Controles <-> configuração ---------------- */
  function coerce(raw, type) {
    if (type === 'number') { const n = Number(raw); return Number.isFinite(n) ? n : 0; }
    if (type === 'bool') return raw === 'true';
    return raw;
  }
  function readEl(el) {
    if (el.type === 'checkbox') return el.checked;
    if (el.dataset.type === 'lines') return el.value.split('\n').map(l => l.trim()).filter(Boolean);
    return coerce(el.value, el.dataset.type);
  }
  function writeEl(el, v) {
    if (el.type === 'checkbox') el.checked = !!v;
    else if (el.type === 'radio') el.checked = String(v) === el.value;
    else if (el.dataset.type === 'lines') el.value = (v || []).join('\n');
    else el.value = v;
  }

  function syncControls() {
    $$('[data-bind]').forEach(el => {
      if (el === document.activeElement) return; // não atrapalha quem está digitando
      writeEl(el, get(cfg, el.dataset.bind));
    });
    $$('[data-out]').forEach(o => { o.textContent = get(cfg, o.dataset.out) + (o.dataset.suffix || ''); });
    $$('[data-card]').forEach(c => {
      const el = getEl(c.dataset.card);
      if (!el) return;
      c.toggleAttribute('data-off', !el.enabled);
      c.classList.toggle('selected', c.dataset.card === selected);
    });
    $('#threshold-field').hidden = cfg.image.mode !== 'threshold';
    markActiveThumb();
    updateReadout();
    renderWeather();
  }

  function bindEl(el) {
    el.addEventListener(el.type === 'radio' ? 'change' : 'input', () => {
      if (el.type === 'radio' && !el.checked) return;
      const path = el.dataset.bind;
      const k = selectionFor(path);
      if (k && /\.angle$/.test(path) && boxes[k]) {
        const b = boxes[k];
        recenter = { k, cx: b.x + b.w / 2, cy: b.y + b.h / 2 };
      }
      set(cfg, path, readEl(el));
      if (path === 'weather.provider') providerChanged();
      if (k) select(k);
      changed();
    });
  }

  function bindControls() {
    $$('[data-bind]').forEach(bindEl);
    $$('[data-card]').forEach(c =>
      c.addEventListener('pointerdown', () => select(c.dataset.card)));
  }

  /* ---------------- Textos livres (lista dinâmica) ---------------- */
  function renderTexts() {
    const list = $('#texts-list');
    list.replaceChildren();
    cfg.texts.forEach((_, i) => {
      const html = $('#tpl-text').innerHTML.replaceAll('__I__', i).replaceAll('__N__', i + 1);
      const wrap = document.createElement('div');
      wrap.innerHTML = html.trim();
      const card = wrap.firstElementChild;
      $$('[data-bind]', card).forEach(bindEl);
      card.addEventListener('pointerdown', () => select(card.dataset.card));
      $('[data-remove]', card).addEventListener('click', () => removeText(i));
      list.append(card);
    });
    $('#add-text').disabled = cfg.texts.length >= MAX_TEXTS;
    syncTextHandles();
  }

  function syncTextHandles() {
    const want = cfg.texts.map((_, i) => `text:${i}`);
    $$('.handle[data-el^="text:"]').forEach(h => { if (!want.includes(h.dataset.el)) h.remove(); });
    want.forEach(k => {
      if ($(`.handle[data-el="${k}"]`)) return;
      const h = document.createElement('div');
      h.className = 'handle';
      h.dataset.el = k;
      h.tabIndex = 0;
      h.setAttribute('role', 'button');
      h.setAttribute('aria-label', `${nameOf(k)}: arraste ou use as setas`);
      h.hidden = true;
      $('#screen').append(h);
      bindHandle(h);
    });
  }

  function addText() {
    if (cfg.texts.length >= MAX_TEXTS) return;
    const n = cfg.texts.length;
    cfg.texts.push({ ...TEXT_DEFAULT, x: 10 + 8 * n, y: 10 + 10 * n });
    renderTexts();
    select(`text:${n}`);
    changed();
  }

  function removeText(i) {
    cfg.texts.splice(i, 1);
    selected = 'time';
    renderTexts();
    changed();
  }

  function changed() {
    syncControls();
    schedulePreview();
    updateDirty();
  }

  function select(k) {
    selected = k;
    $$('.handle').forEach(h => h.classList.toggle('selected', h.dataset.el === k));
    $$('[data-card]').forEach(c => c.classList.toggle('selected', c.dataset.card === k));
    updateReadout();
  }

  function updateReadout() {
    const c = getEl(selected) || cfg.time;
    $('#readout').innerHTML = '';
    const name = document.createElement('b');
    name.textContent = nameOf(selected) || NAMES.time;
    const x = document.createElement('span'); x.textContent = `x ${c.x}`;
    const y = document.createElement('span'); y.textContent = `y ${c.y}`;
    $('#readout').append(name, x, y);
  }

  function updateDirty() {
    const dirty = JSON.stringify(cfg) !== JSON.stringify(applied);
    $('#applybar').classList.toggle('dirty', dirty);
    $('#dirty-text').textContent = dirty ? 'Alterações ainda não aplicadas' : 'Tudo aplicado na tela';
    $('#discard').disabled = !dirty;
  }

  /* ---------------- Prévia (renderizada pelo próprio Pi) ---------------- */
  let previewTimer = null, previewSeq = 0;

  function schedulePreview(delay = 110) {
    clearTimeout(previewTimer);
    previewTimer = setTimeout(fetchPreview, delay);
  }

  async function fetchPreview() {
    const seq = ++previewSeq;
    try {
      const r = await jsonPost('/api/preview', cfg);
      const d = await r.json();
      if (seq !== previewSeq) return; // resposta antiga
      $('#preview').src = d.image;
      boxes = d.boxes;
      if (recenter) {  // girou o texto: mantém o centro onde estava
        const { k, cx, cy } = recenter;
        recenter = null;
        const b = boxes[k], el = getEl(k);
        if (b && el) {
          const nx = Math.round(cx - b.w / 2), ny = Math.round(cy - b.h / 2);
          if (nx !== el.x || ny !== el.y) {
            el.x = nx; el.y = ny; b.x = nx; b.y = ny;
            syncControls(); updateDirty(); schedulePreview(0);
          }
        }
      }
      layoutHandles();
    } catch (e) {
      setStatus('err', 'Sem conexão com o Pi');
    }
  }

  /* ---------------- Simulador: alças de arrastar ---------------- */
  function fitScale() {
    const w = $('.stage').clientWidth - 64;
    scale = clamp(Math.floor((w / W) * 2) / 2, 1, 3);
    document.documentElement.style.setProperty('--s', scale);
    $('#screen').classList.toggle('no-grid', scale < 2);
    layoutHandles();
  }

  function layoutHandles() {
    if (!cfg) return;
    $$('.handle').forEach(h => {
      const k = h.dataset.el, b = boxes[k], el = getEl(k);
      const on = el && el.enabled && b;
      h.hidden = !on;
      if (!on) return;
      Object.assign(h.style, {
        left: b.x * scale + 'px', top: b.y * scale + 'px',
        width: Math.max(b.w * scale, 8) + 'px', height: Math.max(b.h * scale, 8) + 'px',
      });
      h.classList.toggle('selected', k === selected);
    });
  }

  function moveTo(k, x, y) {
    const b = boxes[k];
    if (!b) return;
    x = Math.round(clamp(x, Math.min(0, W - b.w), Math.max(0, W - b.w)));
    y = Math.round(clamp(y, Math.min(0, H - b.h), Math.max(0, H - b.h)));
    const el = getEl(k);
    el.x = x; el.y = y;
    b.x = x; b.y = y;
    layoutHandles();
    changed();
  }

  function bindHandle(h) {
    const k = h.dataset.el;

    h.addEventListener('pointerdown', e => {
      e.preventDefault();
      select(k);
      h.focus({ preventScroll: true });
      h.setPointerCapture(e.pointerId);
      h.classList.add('dragging');
      const el = getEl(k);
      const sx = e.clientX, sy = e.clientY, ox = el.x, oy = el.y;
      const move = ev => moveTo(k, ox + (ev.clientX - sx) / scale, oy + (ev.clientY - sy) / scale);
      const up = () => {
        h.classList.remove('dragging');
        h.removeEventListener('pointermove', move);
        h.removeEventListener('pointerup', up);
        h.removeEventListener('pointercancel', up);
      };
      h.addEventListener('pointermove', move);
      h.addEventListener('pointerup', up);
      h.addEventListener('pointercancel', up);
    });

    h.addEventListener('focus', () => select(k));
    h.addEventListener('keydown', e => {
      const dir = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
      if (!dir) return;
      e.preventDefault();
      const step = e.shiftKey ? 5 : 1, el = getEl(k);
      moveTo(k, el.x + dir[0] * step, el.y + dir[1] * step);
    });
  }

  function bindStage() {
    $$('.handle').forEach(bindHandle);

    $('#center-x').addEventListener('click', () => {
      const b = boxes[selected];
      if (b) moveTo(selected, (W - b.w) / 2, getEl(selected).y);
    });
    $('#center-y').addEventListener('click', () => {
      const b = boxes[selected];
      if (b) moveTo(selected, getEl(selected).x, (H - b.h) / 2);
    });

    new ResizeObserver(fitScale).observe($('.stage'));
  }

  /* ---------------- Galeria de imagens ---------------- */
  async function loadImages() {
    images = await (await fetch('/api/images')).json();
    buildGallery();
  }

  function markActiveThumb() {
    $$('.thumb').forEach(t => t.classList.toggle('active', t.dataset.name === cfg.image.file));
  }

  function buildGallery() {
    const g = $('#gallery');
    g.replaceChildren();
    $('#gallery-empty').hidden = images.length > 0;
    for (const it of images) {
      const box = document.createElement('div');
      box.className = 'thumb';
      box.dataset.name = it.name;

      const pick = document.createElement('button');
      pick.type = 'button';
      pick.className = 'thumb-pick';
      pick.title = 'Usar esta imagem';
      const img = document.createElement('img');
      img.src = '/api/images/' + encodeURIComponent(it.name);
      img.alt = '';
      img.loading = 'lazy';
      pick.append(img);
      pick.addEventListener('click', () => {
        cfg.image.file = it.name;
        cfg.image.enabled = true;
        select('image');
        changed();
      });

      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'thumb-del';
      del.setAttribute('aria-label', 'Remover imagem');
      del.title = 'Remover imagem';
      del.textContent = '×';
      del.addEventListener('click', async () => {
        const r = await fetch('/api/images/' + encodeURIComponent(it.name), { method: 'DELETE' });
        images = (await r.json()).images;
        if (cfg.image.file === it.name) cfg.image.file = '';
        buildGallery();
        changed();
      });

      box.append(pick, del);
      g.append(box);
    }
    markActiveThumb();
  }

  async function upload(file) {
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    try {
      const r = await fetch('/api/images', { method: 'POST', body: fd });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Não foi possível enviar a imagem.');
      images = d.images;
      buildGallery();
      cfg.image.file = d.name;
      cfg.image.enabled = true;
      select('image');
      changed();
    } catch (e) {
      toast(e.message, true);
    }
  }

  function bindImages() {
    const file = $('#file'), drop = $('#drop');
    $('#pick-file').addEventListener('click', () => file.click());
    file.addEventListener('change', () => { upload(file.files[0]); file.value = ''; });
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => {
      e.preventDefault(); drop.classList.add('over');
    }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => {
      e.preventDefault(); drop.classList.remove('over');
    }));
    drop.addEventListener('drop', e => upload(e.dataTransfer.files[0]));

    $('#image-full').addEventListener('click', () => {
      Object.assign(cfg.image, { x: 0, y: 0, w: W, h: H });
      select('image');
      changed();
    });
  }

  /* ---------------- Aplicar na tela ---------------- */
  async function waitJob(job) {
    for (let i = 0; i < 80; i++) {
      const s = await (await fetch('/api/status')).json();
      renderStatus(s);
      if (s.done >= job) {
        if (s.error) throw new Error(s.error);
        return;
      }
      await sleep(400);
    }
    throw new Error('A tela demorou demais para responder.');
  }

  async function runJob(url, body, okMessage, busyLabel) {
    const btn = $('#apply');
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = busyLabel;
    try {
      const r = await jsonPost(url, body);
      if (!r.ok) throw new Error('O Pi recusou a configuração.');
      const { job } = await r.json();
      if (body) { applied = clone(cfg); updateDirty(); }
      await waitJob(job);
      toast(okMessage);
      if (url === '/api/apply') { setTimeout(loadWeather, 3000); setTimeout(loadWeather, 9000); }
    } catch (e) {
      toast('Falhou: ' + e.message, true);
    } finally {
      btn.disabled = false;
      btn.textContent = label;
    }
  }

  function bindActions() {
    $('#apply').addEventListener('click', () =>
      runJob('/api/apply', cfg, 'Aplicado na tela', 'Enviando…'));
    $('#deep-refresh').addEventListener('click', () =>
      runJob('/api/refresh', null, 'Tela redesenhada', 'Redesenhando…'));
    $('#discard').addEventListener('click', () => {
      cfg = clone(applied);
      renderTexts();
      syncControls();
      schedulePreview(0);
      updateDirty();
    });
    $('#theme').addEventListener('click', () => {
      const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.dataset.theme = next;
      localStorage.setItem('tama-theme', next);
    });
  }

  /* ---------------- Jorginho ---------------- */
  async function speak(kind, btn) {
    btn.disabled = true;
    try {
      const r = await jsonPost('/api/mascot/speak', { kind });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'O Jorginho não conseguiu falar.');
      fetchPreview();
      await waitJob(d.job);
      toast('O Jorginho falou');
    } catch (e) {
      toast(e.message, true);
    } finally {
      btn.disabled = false;
    }
  }

  function bindMascot() {
    $$('select[data-hours]').forEach(sel => {
      for (let h = 0; h < 24; h++) sel.add(new Option(String(h).padStart(2, '0') + 'h', h));
    });
    $('#speak-any').addEventListener('click', e => speak(null, e.currentTarget));
    $('#speak-joke').addEventListener('click', e => speak('joke', e.currentTarget));
    $('#speak-weather').addEventListener('click', e => speak('weather', e.currentTarget));
    $('#preset-bubble').addEventListener('click', () => {
      Object.assign(cfg.time, { enabled: true, x: 6, y: 1, size: 38, format: '24h' });
      Object.assign(cfg.date, { enabled: true, x: 8, y: 45, size: 12, format: 'long' });
      Object.assign(cfg.weatherbox, { enabled: true, x: 134, y: 3, size: 40, w: 112, show_range: true, show_text: false });
      Object.assign(cfg.mascot, { enabled: true, x: 4, y: 63, w: 242, size: 11, max_lines: 3, tail: true });
      select('mascot');
      changed();
    });
  }

  /* ---------------- Previsão do tempo ---------------- */
  let weatherInfo = null;

  async function loadWeather() {
    try { weatherInfo = await (await fetch('/api/weather')).json(); } catch { return; }
    renderWeather();
  }

  function providerChanged() {
    const w = cfg.weather;
    if (w.location_provider !== w.provider) {
      w.location_key = ''; w.location_name = ''; w.location_provider = '';
    }
    $('#city-results').replaceChildren();
  }

  function line(cls, text) {
    const d = document.createElement('div');
    d.className = cls;
    d.textContent = text;
    return d;
  }

  function renderWeather() {
    if (!cfg) return;
    const w = cfg.weather, accu = w.provider === 'accuweather', info = weatherInfo || {};
    $$('[data-accu]').forEach(e => { e.hidden = !accu; });
    $$('[data-meteo]').forEach(e => { e.hidden = accu; });
    $('#cap').textContent = info.daily_cap ?? 100;
    $('#key-state').textContent = info.has_key ? (info.key_from_env ? 'definida no sistema' : 'salva') : 'nenhuma salva';

    const hasLoc = !!w.location_key && w.location_provider === w.provider;
    $('#loc-state').textContent = hasLoc ? w.location_name : 'nenhuma escolhida';

    const box = $('#weather-box');
    box.replaceChildren();
    const pending = hasLoc && applied &&
      (applied.weather.location_key !== w.location_key || applied.weather.provider !== w.provider);
    const fresh = hasLoc && info.tag === `${w.provider}:${w.location_key}`;
    const fmt = v => (v == null ? '?' : Math.round(v) + '°');

    if (pending) box.append(line('wb-hint', 'Clique em Aplicar para o Pi começar a buscar o clima dessa cidade.'));
    else if (fresh && info.current) {
      const main = line('wb-main', fmt(info.current.temp));
      if (info.current.text) { const t = document.createElement('small'); t.textContent = info.current.text; main.append(t); }
      box.append(main);
      if (info.today) {
        let t = `Hoje: ${fmt(info.today.min)} a ${fmt(info.today.max)}`;
        if (info.today.rain_prob != null) t += `, chuva ${Math.round(info.today.rain_prob)}%`;
        box.append(line('', t));
      }
      if (info.tomorrow) box.append(line('', `Amanhã: ${fmt(info.tomorrow.min)} a ${fmt(info.tomorrow.max)}`));
      box.append(line('wb-muted', `Atualizado às ${info.updated}` +
        (accu ? `. Chamadas hoje: ${info.calls_today} de ${info.daily_cap}; no mês: ${info.calls_month}.` : '.')));
    } else if (hasLoc) box.append(line('wb-muted', 'Ainda sem dados desta cidade. Clique em "Atualizar clima agora".'));
    if (fresh && info.error) box.append(line('wb-error', info.error));
    box.hidden = !box.childElementCount;
  }

  async function searchCity() {
    const q = $('#city-q').value.trim(), out = $('#city-results'), btn = $('#city-search');
    out.replaceChildren();
    if (q.length < 2) return toast('Digite pelo menos 2 letras.', true);
    btn.disabled = true;
    try {
      const r = await fetch(`/api/weather/search?provider=${encodeURIComponent(cfg.weather.provider)}&q=${encodeURIComponent(q)}`);
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Não foi possível buscar.');
      if (!d.results.length) { out.textContent = 'Nenhuma cidade encontrada.'; return; }
      for (const c of d.results) {
        const label = [c.name, c.area, c.country].filter(Boolean).join(', ');
        const b = document.createElement('button');
        b.type = 'button'; b.className = 'result'; b.textContent = label;
        b.addEventListener('click', () => {
          Object.assign(cfg.weather, { location_key: c.key, location_name: label, location_provider: cfg.weather.provider });
          out.replaceChildren();
          changed();
        });
        out.append(b);
      }
    } catch (e) {
      toast(e.message, true);
    } finally {
      btn.disabled = false;
    }
  }

  function bindWeather() {
    $('#city-search').addEventListener('click', searchCity);
    $('#city-q').addEventListener('keydown', e => { if (e.key === 'Enter') searchCity(); });
    $('#save-key').addEventListener('click', async () => {
      const input = $('#accu-key');
      const r = await jsonPost('/api/weather/key', { key: input.value });
      const d = await r.json();
      if (!r.ok) return toast(d.error || 'Não foi possível salvar a chave.', true);
      input.value = '';
      weatherInfo = d;
      renderWeather();
      toast('Chave salva no Pi');
    });
    $('#weather-refresh').addEventListener('click', async e => {
      const btn = e.currentTarget;
      btn.disabled = true;
      try {
        const r = await jsonPost('/api/weather/refresh');
        const d = await r.json();
        if (!r.ok) throw new Error(d.error || 'Não foi possível atualizar o clima.');
        weatherInfo = d;
        renderWeather();
        toast('Clima atualizado');
      } catch (err) {
        toast(err.message, true);
      } finally {
        btn.disabled = false;
      }
    });
  }

  /* ---------------- Status e avisos ---------------- */
  function setStatus(state, text, title = '') {
    const el = $('#status');
    el.dataset.state = state;
    el.title = title;
    $('#status-text').textContent = text;
  }

  function renderStatus(s) {
    if (s.updating) return setStatus('busy', 'Atualizando a tela…');
    if (s.error) return setStatus('err', 'Erro na tela', s.error);
    if (s.mock) return setStatus('mock', 'Simulação (sem tela)', s.note || '');
    setStatus('ok', s.last_update ? `Tela atualizada às ${s.last_update}` : 'Tela pronta');
  }

  async function pollOnce() {
    try { renderStatus(await (await fetch('/api/status')).json()); }
    catch { setStatus('err', 'Sem conexão com o Pi'); }
  }

  async function pollStatus() {
    document.addEventListener('visibilitychange', () => { if (!document.hidden) pollOnce(); });
    for (;;) {
      if (!document.hidden) await pollOnce();   // aba escondida não consulta o Pi
      await sleep(10000);
    }
  }

  let toastTimer = null;
  function toast(msg, isError = false) {
    const t = $('#toast');
    t.textContent = msg;
    t.className = 'toast' + (isError ? ' error' : '');
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, isError ? 6000 : 2500);
  }

  /* ---------------- Início ---------------- */
  async function init() {
    cfg = await (await fetch('/api/config')).json();
    applied = clone(cfg);
    bindControls();
    $('#add-text').addEventListener('click', addText);
    renderTexts();
    bindStage();
    bindImages();
    bindActions();
    bindMascot();
    bindWeather();
    fitScale();
    syncControls();
    updateDirty();
    fetchPreview();
    loadImages();
    loadWeather();
    pollStatus();
  }

  init().catch(() => setStatus('err', 'Não foi possível carregar a configuração'));
})();
