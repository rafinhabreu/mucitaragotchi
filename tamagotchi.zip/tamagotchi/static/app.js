(() => {
  'use strict';

  const W = 250, H = 122;
  const NAMES = { time: 'Hora', date: 'Data', image: 'Imagem' };

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const clone = o => JSON.parse(JSON.stringify(o));
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const get = (o, p) => p.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
  const set = (o, p, v) => {
    const ks = p.split('.'), last = ks.pop();
    ks.reduce((a, k) => a[k], o)[last] = v;
  };
  const jsonPost = (url, body) => fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body ?? {}),
  });

  let cfg = null;        // o que está sendo editado
  let applied = null;    // o que está na tela do aparelho
  let boxes = {};        // caixas dos elementos, calculadas pelo servidor
  let images = [];
  let selected = 'time';
  let scale = 2;

  /* ---------------- Controles <-> configuração ---------------- */
  function coerce(raw, type) {
    if (type === 'number') { const n = Number(raw); return Number.isFinite(n) ? n : 0; }
    if (type === 'bool') return raw === 'true';
    return raw;
  }
  function readEl(el) {
    return el.type === 'checkbox' ? el.checked : coerce(el.value, el.dataset.type);
  }
  function writeEl(el, v) {
    if (el.type === 'checkbox') el.checked = !!v;
    else if (el.type === 'radio') el.checked = String(v) === el.value;
    else el.value = v;
  }

  function syncControls() {
    $$('[data-bind]').forEach(el => {
      if (el === document.activeElement) return; // não atrapalha quem está digitando
      writeEl(el, get(cfg, el.dataset.bind));
    });
    $$('[data-out]').forEach(o => { o.textContent = get(cfg, o.dataset.out); });
    $$('[data-card]').forEach(c => {
      c.toggleAttribute('data-off', !cfg[c.dataset.card].enabled);
      c.classList.toggle('selected', c.dataset.card === selected);
    });
    $('#threshold-field').hidden = cfg.image.mode !== 'threshold';
    markActiveThumb();
    updateReadout();
  }

  function bindControls() {
    $$('[data-bind]').forEach(el => {
      el.addEventListener(el.type === 'radio' ? 'change' : 'input', () => {
        if (el.type === 'radio' && !el.checked) return;
        const path = el.dataset.bind;
        set(cfg, path, readEl(el));
        const key = path.split('.')[0];
        if (NAMES[key]) select(key);
        changed();
      });
    });
    $$('[data-card]').forEach(c =>
      c.addEventListener('pointerdown', () => select(c.dataset.card)));
  }

  function changed() {
    syncControls();
    schedulePreview();
    updateDirty();
  }

  function select(k) {
    selected = k;
    $$('.handle').forEach(h => h.classList.toggle('selected', h.dataset.el === k));
    $$('[data-card]').forEach(c => c.classList.toggle('selected', c.dataset.card === k));
    updateReadout();
  }

  function updateReadout() {
    const c = cfg[selected];
    $('#readout').innerHTML = '';
    const name = document.createElement('b');
    name.textContent = NAMES[selected];
    const x = document.createElement('span'); x.textContent = `x ${c.x}`;
    const y = document.createElement('span'); y.textContent = `y ${c.y}`;
    $('#readout').append(name, x, y);
  }

  function updateDirty() {
    const dirty = JSON.stringify(cfg) !== JSON.stringify(applied);
    $('#applybar').classList.toggle('dirty', dirty);
    $('#dirty-text').textContent = dirty ? 'Alterações ainda não aplicadas' : 'Tudo aplicado na tela';
    $('#discard').disabled = !dirty;
  }

  /* ---------------- Prévia (renderizada pelo próprio Pi) ---------------- */
  let previewTimer = null, previewSeq = 0;

  function schedulePreview(delay = 110) {
    clearTimeout(previewTimer);
    previewTimer = setTimeout(fetchPreview, delay);
  }

  async function fetchPreview() {
    const seq = ++previewSeq;
    try {
      const r = await jsonPost('/api/preview', cfg);
      const d = await r.json();
      if (seq !== previewSeq) return; // resposta antiga
      $('#preview').src = d.image;
      boxes = d.boxes;
      layoutHandles();
    } catch (e) {
      setStatus('err', 'Sem conexão com o Pi');
    }
  }

  /* ---------------- Simulador: alças de arrastar ---------------- */
  function fitScale() {
    const w = $('.stage').clientWidth - 64;
    scale = clamp(Math.floor((w / W) * 2) / 2, 1, 3);
    document.documentElement.style.setProperty('--s', scale);
    $('#screen').classList.toggle('no-grid', scale < 2);
    layoutHandles();
  }

  function layoutHandles() {
    if (!cfg) return;
    $$('.handle').forEach(h => {
      const k = h.dataset.el, b = boxes[k];
      const on = cfg[k].enabled && b;
      h.hidden = !on;
      if (!on) return;
      Object.assign(h.style, {
        left: b.x * scale + 'px', top: b.y * scale + 'px',
        width: Math.max(b.w * scale, 8) + 'px', height: Math.max(b.h * scale, 8) + 'px',
      });
      h.classList.toggle('selected', k === selected);
    });
  }

  function moveTo(k, x, y) {
    const b = boxes[k];
    if (!b) return;
    x = Math.round(clamp(x, Math.min(0, W - b.w), Math.max(0, W - b.w)));
    y = Math.round(clamp(y, Math.min(0, H - b.h), Math.max(0, H - b.h)));
    cfg[k].x = x; cfg[k].y = y;
    b.x = x; b.y = y;
    layoutHandles();
    changed();
  }

  function bindStage() {
    $$('.handle').forEach(h => {
      const k = h.dataset.el;

      h.addEventListener('pointerdown', e => {
        e.preventDefault();
        select(k);
        h.focus({ preventScroll: true });
        h.setPointerCapture(e.pointerId);
        h.classList.add('dragging');
        const sx = e.clientX, sy = e.clientY, ox = cfg[k].x, oy = cfg[k].y;
        const move = ev => moveTo(k, ox + (ev.clientX - sx) / scale, oy + (ev.clientY - sy) / scale);
        const up = () => {
          h.classList.remove('dragging');
          h.removeEventListener('pointermove', move);
          h.removeEventListener('pointerup', up);
          h.removeEventListener('pointercancel', up);
        };
        h.addEventListener('pointermove', move);
        h.addEventListener('pointerup', up);
        h.addEventListener('pointercancel', up);
      });

      h.addEventListener('focus', () => select(k));
      h.addEventListener('keydown', e => {
        const dir = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
        if (!dir) return;
        e.preventDefault();
        const step = e.shiftKey ? 5 : 1;
        moveTo(k, cfg[k].x + dir[0] * step, cfg[k].y + dir[1] * step);
      });
    });

    $('#center-x').addEventListener('click', () => {
      const b = boxes[selected];
      if (b) moveTo(selected, (W - b.w) / 2, cfg[selected].y);
    });
    $('#center-y').addEventListener('click', () => {
      const b = boxes[selected];
      if (b) moveTo(selected, cfg[selected].x, (H - b.h) / 2);
    });

    new ResizeObserver(fitScale).observe($('.stage'));
  }

  /* ---------------- Galeria de imagens ---------------- */
  async function loadImages() {
    images = await (await fetch('/api/images')).json();
    buildGallery();
  }

  function markActiveThumb() {
    $$('.thumb').forEach(t => t.classList.toggle('active', t.dataset.name === cfg.image.file));
  }

  function buildGallery() {
    const g = $('#gallery');
    g.replaceChildren();
    $('#gallery-empty').hidden = images.length > 0;
    for (const it of images) {
      const box = document.createElement('div');
      box.className = 'thumb';
      box.dataset.name = it.name;

      const pick = document.createElement('button');
      pick.type = 'button';
      pick.className = 'thumb-pick';
      pick.title = 'Usar esta imagem';
      const img = document.createElement('img');
      img.src = '/api/images/' + encodeURIComponent(it.name);
      img.alt = '';
      img.loading = 'lazy';
      pick.append(img);
      pick.addEventListener('click', () => {
        cfg.image.file = it.name;
        cfg.image.enabled = true;
        select('image');
        changed();
      });

      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'thumb-del';
      del.setAttribute('aria-label', 'Remover imagem');
      del.title = 'Remover imagem';
      del.textContent = '×';
      del.addEventListener('click', async () => {
        const r = await fetch('/api/images/' + encodeURIComponent(it.name), { method: 'DELETE' });
        images = (await r.json()).images;
        if (cfg.image.file === it.name) cfg.image.file = '';
        buildGallery();
        changed();
      });

      box.append(pick, del);
      g.append(box);
    }
    markActiveThumb();
  }

  async function upload(file) {
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    try {
      const r = await fetch('/api/images', { method: 'POST', body: fd });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Não foi possível enviar a imagem.');
      images = d.images;
      buildGallery();
      cfg.image.file = d.name;
      cfg.image.enabled = true;
      select('image');
      changed();
    } catch (e) {
      toast(e.message, true);
    }
  }

  function bindImages() {
    const file = $('#file'), drop = $('#drop');
    $('#pick-file').addEventListener('click', () => file.click());
    file.addEventListener('change', () => { upload(file.files[0]); file.value = ''; });
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => {
      e.preventDefault(); drop.classList.add('over');
    }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => {
      e.preventDefault(); drop.classList.remove('over');
    }));
    drop.addEventListener('drop', e => upload(e.dataTransfer.files[0]));

    $('#image-full').addEventListener('click', () => {
      Object.assign(cfg.image, { x: 0, y: 0, w: W, h: H });
      select('image');
      changed();
    });
  }

  /* ---------------- Aplicar na tela ---------------- */
  async function waitJob(job) {
    for (let i = 0; i < 80; i++) {
      const s = await (await fetch('/api/status')).json();
      renderStatus(s);
      if (s.done >= job) {
        if (s.error) throw new Error(s.error);
        return;
      }
      await sleep(400);
    }
    throw new Error('A tela demorou demais para responder.');
  }

  async function runJob(url, body, okMessage, busyLabel) {
    const btn = $('#apply');
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = busyLabel;
    try {
      const r = await jsonPost(url, body);
      if (!r.ok) throw new Error('O Pi recusou a configuração.');
      const { job } = await r.json();
      if (body) { applied = clone(cfg); updateDirty(); }
      await waitJob(job);
      toast(okMessage);
    } catch (e) {
      toast('Falhou: ' + e.message, true);
    } finally {
      btn.disabled = false;
      btn.textContent = label;
    }
  }

  function bindActions() {
    $('#apply').addEventListener('click', () =>
      runJob('/api/apply', cfg, 'Aplicado na tela', 'Enviando…'));
    $('#deep-refresh').addEventListener('click', () =>
      runJob('/api/refresh', null, 'Tela redesenhada', 'Redesenhando…'));
    $('#discard').addEventListener('click', () => {
      cfg = clone(applied);
      syncControls();
      schedulePreview(0);
      updateDirty();
    });
    $('#theme').addEventListener('click', () => {
      const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.dataset.theme = next;
      localStorage.setItem('tama-theme', next);
    });
  }

  /* ---------------- Status e avisos ---------------- */
  function setStatus(state, text, title = '') {
    const el = $('#status');
    el.dataset.state = state;
    el.title = title;
    $('#status-text').textContent = text;
  }

  function renderStatus(s) {
    if (s.updating) return setStatus('busy', 'Atualizando a tela…');
    if (s.error) return setStatus('err', 'Erro na tela', s.error);
    if (s.mock) return setStatus('mock', 'Simulação (sem tela)', s.note || '');
    setStatus('ok', s.last_update ? `Tela atualizada às ${s.last_update}` : 'Tela pronta');
  }

  async function pollStatus() {
    for (;;) {
      try { renderStatus(await (await fetch('/api/status')).json()); }
      catch { setStatus('err', 'Sem conexão com o Pi'); }
      await sleep(4000);
    }
  }

  let toastTimer = null;
  function toast(msg, isError = false) {
    const t = $('#toast');
    t.textContent = msg;
    t.className = 'toast' + (isError ? ' error' : '');
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, isError ? 6000 : 2500);
  }

  /* ---------------- Início ---------------- */
  async function init() {
    cfg = await (await fetch('/api/config')).json();
    applied = clone(cfg);
    bindControls();
    bindStage();
    bindImages();
    bindActions();
    fitScale();
    syncControls();
    updateDirty();
    fetchPreview();
    loadImages();
    pollStatus();
  }

  init().catch(() => setStatus('err', 'Não foi possível carregar a configuração'));
})();
