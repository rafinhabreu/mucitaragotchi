"""Ícones de clima desenhados com formas simples (nítidos em 1 bit, em qualquer tamanho)
e classificação do texto/código das APIs em uma categoria de ícone."""
import math
import re
import unicodedata

KINDS = ("sun", "partly", "cloud", "rain", "storm", "snow", "fog")

# Categorias dos ícones numéricos da AccuWeather (usados só se o texto não bastar)
_ACCU = {
    **{n: "sun" for n in (1, 2, 30, 33, 34)},
    **{n: "partly" for n in (3, 4, 5, 35, 36, 37)},
    **{n: "cloud" for n in (6, 7, 8, 32, 38)},
    11: "fog",
    **{n: "rain" for n in (12, 13, 14, 18, 25, 26, 29, 39, 40)},
    **{n: "storm" for n in (15, 16, 17, 41, 42)},
    **{n: "snow" for n in (19, 20, 21, 22, 23, 24, 31, 43, 44)},
}

_RULES = (  # a ordem importa: o mais "forte" primeiro
    ("storm", r"trovoad|tempestade|raio"),
    ("snow", r"neve|granizo|gelo|geada|nevasca"),
    ("rain", r"chuva|chuvisc|garoa|pancada|aguaceiro|temporal"),
    ("fog", r"nevoa|neblina|nevoeiro|bruma|enevoad"),
    ("partly", r"parcialmente|intermitente|poucas nuvens|sol e nuvens|nuvens e sol|claros"),
    ("cloud", r"nublad|encoberto|nuvens|nuvem|cinzento"),
    ("sun", r"sol|limpo|claro|ensolarad|quente"),
)


def _plain(text):
    text = unicodedata.normalize("NFD", (text or "").lower())
    return "".join(c for c in text if unicodedata.category(c) != "Mn")


def classify(text, icon_id=None):
    t = _plain(text)
    for kind, pattern in _RULES:
        if re.search(pattern, t):
            return kind
    try:
        return _ACCU.get(int(icon_id), "cloud")
    except (TypeError, ValueError):
        return "cloud"


# --- desenho -------------------------------------------------------------------
_CIRCLES = ((0.22, 0.42, 0.16), (0.44, 0.30, 0.26), (0.72, 0.42, 0.16))
_BASE = (0.22, 0.42, 0.72, 0.58)


def _cloud(d, ox, oy, u, fg, bg, t):
    """Nuvem só com contorno; o miolo em bg esconde o que estiver atrás."""
    for cx, cy, r in _CIRCLES:
        d.ellipse([ox + (cx - r) * u, oy + (cy - r) * u, ox + (cx + r) * u, oy + (cy + r) * u], fill=fg)
    d.rectangle([ox + _BASE[0] * u, oy + _BASE[1] * u, ox + _BASE[2] * u, oy + _BASE[3] * u], fill=fg)
    for cx, cy, r in _CIRCLES:
        ri = r * u - t
        d.ellipse([ox + cx * u - ri, oy + cy * u - ri, ox + cx * u + ri, oy + cy * u + ri], fill=bg)
    d.rectangle([ox + _BASE[0] * u, oy + _BASE[1] * u, ox + _BASE[2] * u, oy + _BASE[3] * u - t], fill=bg)


def _sun(d, cx, cy, r, fg, t, rays=True):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=fg)
    if rays:
        for i in range(8):
            a = i * math.pi / 4
            d.line([cx + math.cos(a) * r * 1.5, cy + math.sin(a) * r * 1.5,
                    cx + math.cos(a) * r * 2.15, cy + math.sin(a) * r * 2.15], fill=fg, width=t)


def _moon(d, cx, cy, r, fg, bg):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=fg)
    d.ellipse([cx - r * 0.78 + r * 0.55, cy - r * 0.78 - r * 0.35,
               cx + r * 0.78 + r * 0.55, cy + r * 0.78 - r * 0.35], fill=bg)


def draw_icon(d, kind, x, y, s, fg, bg, night=False):
    """Desenha o ícone dentro de um quadrado s×s com canto superior esquerdo em (x, y)."""
    t = max(1, round(s / 18))
    big = lambda: _moon(d, x + s * 0.5, y + s * 0.5, s * 0.30, fg, bg) if night \
        else _sun(d, x + s * 0.5, y + s * 0.5, s * 0.19, fg, t)

    if kind == "sun":
        big()
    elif kind == "partly":
        if night:
            _moon(d, x + s * 0.36, y + s * 0.36, s * 0.22, fg, bg)
        else:
            _sun(d, x + s * 0.36, y + s * 0.34, s * 0.12, fg, t)
        _cloud(d, x + s * 0.10, y + s * 0.26, s * 0.92, fg, bg, t)
    elif kind == "fog":
        for i, (a, b) in enumerate(((0.12, 0.88), (0.22, 0.78), (0.12, 0.88), (0.22, 0.78))):
            yy = y + s * (0.22 + i * 0.16)
            d.line([x + s * a, yy, x + s * b, yy], fill=fg, width=t)
    else:
        top = 0.0 if kind in ("rain", "storm", "snow") else 0.18
        _cloud(d, x + s * 0.04, y + s * top, s * 0.96, fg, bg, t)
        if kind == "rain":
            for cx in (0.30, 0.48, 0.66):
                d.line([x + s * cx, y + s * 0.66, x + s * (cx - 0.07), y + s * 0.86], fill=fg, width=t)
        elif kind == "snow":
            for cx, cy in ((0.30, 0.72), (0.50, 0.84), (0.70, 0.72)):
                r = max(1, t)
                d.ellipse([x + s * cx - r, y + s * cy - r, x + s * cx + r, y + s * cy + r], fill=fg)
        elif kind == "storm":
            pts = [(0.52, 0.58), (0.38, 0.80), (0.49, 0.80), (0.43, 0.98), (0.64, 0.72), (0.53, 0.72), (0.60, 0.58)]
            d.polygon([(x + s * a, y + s * b) for a, b in pts], fill=fg)
