"""Servidor web do Tamagotchi. Acesse http://<hostname>.local:8080"""
import os
import signal
import sys
import threading
import time
import uuid

from flask import Flask, jsonify, request, send_from_directory
from PIL import Image, ImageOps
from werkzeug.utils import secure_filename

import config
import mascot
import renderer
import weather
from display import Worker, log

app = Flask(__name__, static_folder="static", static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024  # uploads de até 12 MB
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

worker = Worker()
poller = weather.Poller()


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# --- configuração, prévia e aplicação -------------------------------------
@app.get("/api/config")
def get_config():
    return jsonify(config.load())


@app.post("/api/preview")
def preview():
    cfg = config.sanitize(request.get_json(silent=True))
    img, boxes = renderer.render(cfg)
    return jsonify(image=renderer.to_data_url(img), boxes=boxes)


@app.post("/api/apply")
def apply_config():
    cfg = config.sanitize(request.get_json(silent=True))
    old_weather = config.load()["weather"]
    config.save(cfg)
    if cfg["weather"] != old_weather:
        poller.poke()  # nova cidade/fonte: busca o clima já
    return jsonify(job=worker.request(full=True))


@app.post("/api/refresh")
def refresh():
    """Limpa a tela e redesenha (ajuda a remover 'fantasmas' do e-ink)."""
    return jsonify(job=worker.request(full=True, clear=True))


@app.get("/api/status")
def status():
    return jsonify(worker.status())


# --- clima ------------------------------------------------------------------------
@app.get("/api/weather")
def weather_info():
    return jsonify(weather.info())


@app.post("/api/weather/key")
def weather_key():
    try:
        weather.set_key((request.get_json(silent=True) or {}).get("key", ""))
    except ValueError as e:
        return jsonify(error=str(e)), 400
    return jsonify(weather.info())


@app.get("/api/weather/search")
def weather_search():
    q = request.args.get("q", "").strip()
    if len(q) < 2:
        return jsonify(error="Digite pelo menos 2 letras."), 400
    try:
        return jsonify(results=weather.search(request.args.get("provider", ""), q))
    except weather.WeatherError as e:
        return jsonify(error=str(e)), 502


@app.post("/api/weather/refresh")
def weather_refresh():
    try:
        weather.refresh(force=True, raise_errors=True)
    except weather.WeatherError as e:
        return jsonify(error=str(e)), 502
    return jsonify(weather.info())


# --- Jorginho -----------------------------------------------------------------------
@app.post("/api/mascot/speak")
def mascot_speak():
    kind = (request.get_json(silent=True) or {}).get("kind") or None
    if kind not in (None, "comment", "joke", "weather"):
        return jsonify(error="Categoria inválida."), 400
    try:
        said = mascot.speak(config.load(), kind)
    except ValueError as e:
        return jsonify(error=str(e)), 409
    return jsonify(job=worker.request(full=False), **said)


# --- imagens ----------------------------------------------------------------
def list_images():
    files = sorted(config.IMAGES.glob("*.png"), key=lambda p: p.stat().st_mtime, reverse=True)
    return [{"name": p.name} for p in files]


@app.get("/api/images")
def images():
    return jsonify(list_images())


@app.post("/api/images")
def upload_image():
    f = request.files.get("file")
    if not f:
        return jsonify(error="Nenhum arquivo enviado."), 400
    try:
        img = Image.open(f.stream)
        img.draft("RGB", (1600, 1600))  # decodifica JPEG grande com menos memória
        img = ImageOps.exif_transpose(img)
        img.thumbnail((800, 800))
        if img.mode not in ("RGB", "RGBA", "L", "LA"):
            img = img.convert("RGBA")
    except Exception:
        return jsonify(error="Esse arquivo não parece ser uma imagem válida."), 400

    stem = secure_filename(os.path.splitext(f.filename or "imagem")[0])[:40] or "imagem"
    name = f"{stem}-{uuid.uuid4().hex[:6]}.png"
    img.save(config.IMAGES / name, "PNG")
    return jsonify(name=name, images=list_images())


@app.get("/api/images/<path:name>")
def get_image(name):
    return send_from_directory(config.IMAGES, secure_filename(name))


@app.delete("/api/images/<path:name>")
def delete_image(name):
    path = config.IMAGES / secure_filename(name)
    if path.is_file():
        path.unlink()
    return jsonify(images=list_images())


# --- vigia: se algo emperrar, reinicia o app (o systemd o sobe de novo) ---------------
MAX_RSS_MB = int(os.environ.get("MAX_RSS_MB", "220"))   # Pi Zero W tem só 512 MB
MAX_UPDATE_S = int(os.environ.get("MAX_UPDATE_S", "120"))
MAX_SILENCE_S = int(os.environ.get("MAX_SILENCE_S", "240"))


def rss_mb():
    try:
        with open("/proc/self/statm") as f:
            return int(f.read().split()[1]) * os.sysconf("SC_PAGE_SIZE") / 1048576
    except (OSError, ValueError, IndexError):
        return 0.0


def guard_check(w, now=None):
    """Devolve o motivo para reiniciar, ou None se está tudo bem."""
    now = now if now is not None else time.monotonic()
    if rss_mb() > MAX_RSS_MB:
        return f"memória acima de {MAX_RSS_MB} MB"
    if w.busy_since and now - w.busy_since > MAX_UPDATE_S:
        return f"atualização da tela presa há mais de {MAX_UPDATE_S} s"
    if not w.busy_since and now - w.beat > MAX_SILENCE_S:
        return f"laço da tela parado há mais de {MAX_SILENCE_S} s"
    return None


def guard_loop():
    while True:
        time.sleep(30)
        reason = guard_check(worker)
        if reason:
            log(f"VIGIA: {reason}. Reiniciando o app.")
            os._exit(3)  # o systemd (Restart=always) sobe tudo de novo em segundos


def _bye(*_):
    worker.shutdown()
    sys.exit(0)


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, _bye)
    signal.signal(signal.SIGINT, _bye)
    worker.start()
    poller.start()
    threading.Thread(target=guard_loop, daemon=True).start()
    port = int(os.environ.get("PORT", "8080"))
    try:
        from waitress import serve  # servidor de produção: limita threads e conexões
    except ImportError:
        log("waitress não instalado (sudo apt install python3-waitress); usando o servidor de desenvolvimento")
        app.run(host="0.0.0.0", port=port, threaded=True)
    else:
        serve(app, host="0.0.0.0", port=port, threads=4, connection_limit=40,
              channel_timeout=30, cleanup_interval=10)
