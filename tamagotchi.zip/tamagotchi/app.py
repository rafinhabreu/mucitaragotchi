"""Servidor web do Tamagotchi. Acesse http://<hostname>.local:8080"""
import os
import signal
import sys
import uuid

from flask import Flask, jsonify, request, send_from_directory
from PIL import Image, ImageOps
from werkzeug.utils import secure_filename

import config
import renderer
from display import Worker

app = Flask(__name__, static_folder="static", static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024  # uploads de até 12 MB
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

worker = Worker()


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# --- configuração, prévia e aplicação -------------------------------------
@app.get("/api/config")
def get_config():
    return jsonify(config.load())


@app.post("/api/preview")
def preview():
    cfg = config.sanitize(request.get_json(silent=True))
    img, boxes = renderer.render(cfg)
    return jsonify(image=renderer.to_data_url(img), boxes=boxes)


@app.post("/api/apply")
def apply_config():
    cfg = config.sanitize(request.get_json(silent=True))
    config.save(cfg)
    return jsonify(job=worker.request(full=True))


@app.post("/api/refresh")
def refresh():
    """Limpa a tela e redesenha (ajuda a remover 'fantasmas' do e-ink)."""
    return jsonify(job=worker.request(full=True, clear=True))


@app.get("/api/status")
def status():
    return jsonify(worker.status())


# --- imagens ----------------------------------------------------------------
def list_images():
    files = sorted(config.IMAGES.glob("*.png"), key=lambda p: p.stat().st_mtime, reverse=True)
    return [{"name": p.name} for p in files]


@app.get("/api/images")
def images():
    return jsonify(list_images())


@app.post("/api/images")
def upload_image():
    f = request.files.get("file")
    if not f:
        return jsonify(error="Nenhum arquivo enviado."), 400
    try:
        img = Image.open(f.stream)
        img.draft("RGB", (1600, 1600))  # decodifica JPEG grande com menos memória
        img = ImageOps.exif_transpose(img)
        img.thumbnail((800, 800))
        if img.mode not in ("RGB", "RGBA", "L", "LA"):
            img = img.convert("RGBA")
    except Exception:
        return jsonify(error="Esse arquivo não parece ser uma imagem válida."), 400

    stem = secure_filename(os.path.splitext(f.filename or "imagem")[0])[:40] or "imagem"
    name = f"{stem}-{uuid.uuid4().hex[:6]}.png"
    img.save(config.IMAGES / name, "PNG")
    return jsonify(name=name, images=list_images())


@app.get("/api/images/<path:name>")
def get_image(name):
    return send_from_directory(config.IMAGES, secure_filename(name))


@app.delete("/api/images/<path:name>")
def delete_image(name):
    path = config.IMAGES / secure_filename(name)
    if path.is_file():
        path.unlink()
    return jsonify(images=list_images())


def _bye(*_):
    worker.shutdown()
    sys.exit(0)


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, _bye)
    signal.signal(signal.SIGINT, _bye)
    worker.start()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8080")), threaded=True)
